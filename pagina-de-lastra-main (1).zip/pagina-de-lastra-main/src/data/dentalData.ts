import { DentalService, TreatmentItem, SmileTip, FaqItem } from '../types';

export const INSTITUTIONAL_INFO = {
  name: 'ODOCARE UABC',
  faculty: 'Facultad de Odontología Mexicali (FOM)',
  university: 'Universidad Autónoma de Baja California',
  tagline: 'Una sonrisa sana comienza aquí',
  phone: '686 557 3268', // ÚNICO teléfono en toda la app
  email: 'paulina.montelongo@uabc.edu.mx',
  howToGetUrl: 'https://www.google.com/maps/dir/?api=1&destination=Facultad+de+Odontologia+UABC+Mexicali',
  portalUrl: 'https://odontologia.mxl.uabc.mx/odo3/',
  facebookUrl: 'https://www.facebook.com/facultadde.odontologiamexicali/?locale=es_LA',
  address: 'Av. Zotoluca y Chinampas S/N, Fraccionamiento Calafia, C.P. 21040, Mexicali, B.C.',
  hours: 'Lunes a Viernes de 8:00 AM a 4:00 PM (Fines de semana sin servicio)',
  clinicName: 'Clínica Calafia - Facultad de Odontología UABC',
  principalLogo: '/assets/aistudio/images__9__9f9fd0f1.jpg',
  heroPhoto: '/assets/aistudio/images__15__b303160e.jpg',
  clinicFacadePhoto: '/assets/aistudio/2016-05-12_d807e606.jpg',
  anniversaryPhoto: '/assets/aistudio/images__13__ae41d135.jpg',
  teamPhoto: '/assets/aistudio/images__11__4c57826c.jpg',
  directoraPhoto: '/assets/aistudio/images__12__02994b08.jpg',
  mascotPhoto: '/assets/aistudio/images__10__9f3f3829.jpg',
  posgradoPhoto: '/assets/aistudio/images__14__3573f8a1.jpg',
};

// Galería institucional puramente decorativa con las fotografías enviadas por el usuario
export const INSTITUTIONAL_GALLERY = [
  {
    image: '/assets/aistudio/images__15__b303160e.jpg',
    title: 'Brigada de Salud Oral',
    subtitle: 'Semana del 50 Aniversario · Juntos por sonrisas más sanas',
    tag: 'Comunidad'
  },
  {
    image: '/assets/aistudio/2016-05-12_d807e606.jpg',
    title: 'Clínica Calafia',
    subtitle: 'Instalaciones y acceso a clínicas odontológicas UABC',
    tag: 'Instalaciones'
  },
  {
    image: '/assets/aistudio/images__11__4c57826c.jpg',
    title: 'Equipo Clínico Docente',
    subtitle: 'Cirujanos dentistas y catedráticos especialistas',
    tag: 'Profesores'
  },
  {
    image: '/assets/aistudio/images__13__ae41d135.jpg',
    title: '50 Años de Odontología',
    subtitle: 'Legado del pasado, sonrisas del presente',
    tag: 'Historia'
  },
  {
    image: '/assets/aistudio/images__12__02994b08.jpg',
    title: 'Dirección FOM 2025-2029',
    subtitle: 'Mtra. Herla Aida Vieira Nevarez',
    tag: 'Dirección'
  },
  {
    image: '/assets/aistudio/images__10__9f3f3829.jpg',
    title: 'Orgullo Cimarrón',
    subtitle: 'Reconocimientos y vida académica universitaria',
    tag: 'UABC'
  },
  {
    image: '/assets/aistudio/images__14__3573f8a1.jpg',
    title: 'Investigación y Posgrados',
    subtitle: 'Doctorado en Ciencias Clínicas Odontológicas',
    tag: 'Posgrado'
  }
];

export const DENTAL_SERVICES: DentalService[] = [
  {
    id: 'preventiva',
    name: '1. Odontología preventiva',
    shortDesc: 'Limpiezas dentales ultrasónicas, aplicación de flúor protector y selladores para mantener tus dientes sanos y libres de sarro.',
    fullDesc: 'La odontología preventiva es la base para una sonrisa sana y radiante toda la vida. En nuestra clínica universitaria realizamos profilaxis profunda con ultrasonido, remoción de sarro supragingival y subgingival, aplicación de barniz de flúor de alta adherencia y selladores de fosetas y fisuras en molares sanos para blindar tus dientes contra la caries.',
    category: 'preventivo',
    image: '/assets/aistudio/images__15__b303160e.jpg',
    iconName: 'Sparkles',
    commonTreatments: [
      'Profilaxis y pulido dental profesional',
      'Remoción de sarro con cavitron ultrasónico',
      'Aplicación de barniz de flúor mineralizante',
      'Selladores de fosetas y fisuras',
      'Técnica personalizada de cepillado e higiene'
    ],
    recommendedFor: 'Toda la familia, recomendado cada 6 meses.',
    sessionDuration: '45 a 60 minutos',
    cuteQuote: '¡Cuidar tus dientes hoy es el secreto de una sonrisa radiante mañana! ✨'
  },
  {
    id: 'operatoria',
    name: '2. Operatoria dental',
    shortDesc: 'Restauraciones estéticas con resina del color exacto de tu diente, curación de caries y reconstrucción dental delicada.',
    fullDesc: 'Especialidad enfocada en devolver la anatomía, función y estética natural a los dientes afectados por caries, fracturas o desgaste. Utilizamos resinas compuestas de última generación con mimetismo óptico que se integran a la perfección con el tono de tus dientes naturales, libres de mercurio y con máxima resistencia.',
    category: 'restaurador',
    image: '/assets/aistudio/images__11__4c57826c.jpg',
    iconName: 'Smile',
    commonTreatments: [
      'Restauraciones directas con resina estética',
      'Eliminación delicada de caries dental',
      'Reconstrucción anatómica de bordes fracturados',
      'Reemplazo de amalgamas oscuras por resinas',
      'Incrustaciones estéticas de laboratorio'
    ],
    recommendedFor: 'Pacientes con cavidades por caries, sensibilidad o dientes despostillados.',
    sessionDuration: '50 a 80 minutos por pieza',
    cuteQuote: 'Dientes como nuevos, naturales y súper estéticos. 💖'
  },
  {
    id: 'periodoncia',
    name: '3. Periodoncia',
    shortDesc: 'Cuidado especializado de encías, eliminación de inflamación, sangrado y tratamiento de gingivitis y periodontitis.',
    fullDesc: 'La periodoncia trata las estructuras que dan soporte a tus dientes: la encía, el ligamento periodontal y el hueso alveolar. Si notas sangrado al cepillarte, encías enrojecidas, mal aliento persistente o ligera movilidad, nuestros estudiantes bajo supervisión de especialistas realizan raspados y alisados radiculares para frenar la infección y recuperar la firmeza.',
    category: 'especialidad',
    image: '/assets/aistudio/images__13__ae41d135.jpg',
    iconName: 'HeartPulse',
    commonTreatments: [
      'Raspado y alisado radicular por cuadrantes',
      'Terapia para gingivitis y sangrado gingival',
      'Control y estabilización de periodontitis',
      'Mantenimiento periodontal periódico',
      'Eliminación de bolsas periodontales'
    ],
    recommendedFor: 'Personas con encías inflamadas, rojas, con sangrado o acumulación profunda de sarro.',
    sessionDuration: '60 minutos por sesión',
    cuteQuote: 'Unas encías rositas y firmes son el marco de tu hermosa sonrisa. 🌸'
  },
  {
    id: 'endodoncia',
    name: '4. Endodoncia',
    shortDesc: 'Tratamiento de conductos suave para aliviar el dolor intenso y salvar tu diente natural evitando extracciones innecesarias.',
    fullDesc: 'Cuando una caries profunda o un golpe lesiona el nervio del diente (pulpa dental), la endodoncia permite desinfectar los conductos de la raíz y sellarlos herméticamente con materiales biocompatibles. Esto elimina el dolor por completo y preserva tu diente en boca para que sigas sonriendo con confianza.',
    category: 'especialidad',
    image: '/assets/aistudio/images__14__3573f8a1.jpg',
    iconName: 'ShieldCheck',
    commonTreatments: [
      'Biopulpectomía / Tratamiento de conductos',
      'Alivio urgente de pulpitis y dolor dental agudo',
      'Tratamiento de abscesos periapicales',
      'Retratamiento endodóntico especializado',
      'Preparación para poste y corona posterior'
    ],
    recommendedFor: 'Dolor dental punzante, sensibilidad extrema al calor/frío o inflamación en la raíz.',
    sessionDuration: '1 a 2 sesiones de 60 a 90 minutos',
    cuteQuote: 'Salvamos tu diente con el mayor cuidado y cero dolor. 💕'
  },
  {
    id: 'cirugia',
    name: '5. Cirugía bucal',
    shortDesc: 'Extracciones dentales seguras, extracción de muelas del juicio y cirugías menores con técnica delicada y anestesia eficaz.',
    fullDesc: 'Servicio dedicado a los procedimientos quirúrgicos de la cavidad oral con estrictos protocolos de bioseguridad y esterilización de grado hospitalario. Realizamos extracción de terceros molares (muelas del juicio impactadas o retenidas), extracciones simples, regularización de rebordes alveolares y liberación de frenillos.',
    category: 'quirurgico',
    image: '/assets/aistudio/2016-05-12_d807e606.jpg',
    iconName: 'Scissors',
    commonTreatments: [
      'Cirugía de muelas del juicio (terceros molares)',
      'Extracciones simples y complejas',
      'Cirugía preprotésica y regularización ósea',
      'Frenectomías lingual y labial',
      'Manejo de dientes retenidos'
    ],
    recommendedFor: 'Molestias por muelas del juicio, dientes no restaurables o indicaciones de ortodoncia.',
    sessionDuration: '45 a 90 minutos',
    cuteQuote: 'Procedimientos gentiles con recuperación acompañada y segura. 🌷'
  },
  {
    id: 'protesis',
    name: '6. Prótesis dental',
    shortDesc: 'Coronas estéticas, puentes fijos, prótesis removibles y totales para devolver la función masticatoria y la armonía de tu rostro.',
    fullDesc: 'Rehabilitamos la pérdida de una o varias piezas dentales mediante prótesis de alta calidad diseñadas a tu medida. Ofrecemos coronas individuales de porcelana y zirconia, puentes fijos, placas parciales removibles con retenedores estéticos y prótesis totales para adultos mayores, devolviendo la capacidad de masticar y sonreír plenamente.',
    category: 'restaurador',
    image: '/assets/aistudio/images__11__4c57826c.jpg',
    iconName: 'Layers',
    commonTreatments: [
      'Coronas individuales de zirconia y porcelana',
      'Puentes dentales fijos estéticos',
      'Prótesis removibles parciales metálicas y acrílicas',
      'Prótesis totales mucosoportadas',
      'Ajustes y rebasados de prótesis existentes'
    ],
    recommendedFor: 'Ausencia de dientes, dificultad para masticar o reconstrucción estética integral.',
    sessionDuration: 'Múltiples citas de ajuste y confección personalizada',
    cuteQuote: 'Vuelve a disfrutar de tus comidas favoritas y a sonreír sin pena. 💫'
  },
  {
    id: 'odontopediatria',
    name: '7. Odontopediatría',
    shortDesc: 'Atención dental dulce, paciente y divertida para bebés, niñas y niños, creando experiencias positivas sin miedo al dentista.',
    fullDesc: 'Nuestras clínicas infantiles están preparadas para recibir a los más pequeños del hogar con calidez, paciencia y técnicas de adaptación psicológica. Brindamos prevención temprana, aplicación de flúor infantil, selladores, pulpotomías, coronitas estéticas pediátricas y orientación de hábitos para un crecimiento maxilofacial armónico.',
    category: 'infantil',
    image: '/assets/aistudio/images__10__9f3f3829.jpg',
    iconName: 'Baby',
    commonTreatments: [
      'Limpiezas y profilaxis dental para niños',
      'Selladores de fosetas para dientes de leche y permanentes',
      'Pulpotomías y terapias pulpares infantiles',
      'Coronas de acero cromo y estéticas para infantes',
      'Mantenedores de espacio y control de hábitos'
    ],
    recommendedFor: 'Bebés desde el primer diente hasta adolescentes de 14 años.',
    sessionDuration: '30 a 45 minutos (amigable y divertido)',
    cuteQuote: 'Experiencias mágicas y cariñosas para las sonrisas más pequeñitas. 🧸'
  },
  {
    id: 'radiologia',
    name: '8. Radiología dental',
    shortDesc: 'Estudios de imagen de alta resolución con sensores digitales y mínima dosis de radiación para diagnósticos certeros.',
    fullDesc: 'Contamos con gabinete radiológico universitario con equipos digitales modernos que reducen la exposición a la radiación hasta en un 80% respecto a los métodos tradicionales. Tomamos radiografías periapicales de detalle, series radiográficas completas, aletas de mordida y panorámicas para la planeación precisa de tus tratamientos.',
    category: 'especialidad',
    image: '/assets/aistudio/images__14__3573f8a1.jpg',
    iconName: 'ScanLine',
    commonTreatments: [
      'Radiografías periapicales digitales de alta nitidez',
      'Radiografías de aleta de mordida (detección interproximal)',
      'Radiografías oclusales para maxilares',
      'Interpretación y reporte radiográfico clínico',
      'Archivo digital para seguimiento de caso'
    ],
    recommendedFor: 'Diagnóstico previo indispensable para casi cualquier tratamiento dental.',
    sessionDuration: '15 a 20 minutos',
    cuteQuote: 'Diagnóstico preciso gracias a la tecnología digital universitaria. 🔬'
  },
  {
    id: 'ortodoncia',
    name: '9. Ortodoncia',
    shortDesc: 'Alineación de dientes, corrección de mordida y ortopedia maxilar para una sonrisa simétrica, sana y hermosa.',
    fullDesc: 'El servicio y posgrado de ortodoncia de la Facultad de Odontología Mexicali diagnostica y corrige las alteraciones en la posición de los dientes y el crecimiento de los maxilares. Desde brackets metálicos y estéticos hasta ortopedia en etapas de desarrollo, logramos armonía facial, oclusión funcional y una sonrisa deslumbrante.',
    category: 'especialidad',
    image: '/assets/aistudio/images__15__b303160e.jpg',
    iconName: 'Star',
    commonTreatments: [
      'Diagnóstico cefalométrico y trazado computarizado',
      'Brackets metálicos y estéticos',
      'Corrección de apiñamiento y mordidas abiertas/cruzadas',
      'Ortopedia funcional maxilar para niños en crecimiento',
      'Retenedores y fase de contención post-tratamiento'
    ],
    recommendedFor: 'Dientes chuecos, apiñados, espacios interdentales o problemas al cerrar la mordida.',
    sessionDuration: 'Consultas mensuales de ajuste y activación',
    cuteQuote: 'Diseñamos la alineación perfecta que te hará brillar todos los días. 🌟'
  }
];

export const TREATMENTS_DIRECTORY: TreatmentItem[] = [
  {
    id: 't1',
    name: 'Limpieza dental ultrasónica con flúor',
    serviceId: 'preventiva',
    serviceName: 'Odontología preventiva',
    symptoms: ['Sarro acumulado', 'Manchas por café o té', 'Mal aliento', 'Higiene preventiva'],
    description: 'Eliminación suave de placa bacteriana calcificada y sarro mediante ultrasonido más pulido con pasta profiláctica y sellado con flúor.',
    prepTip: 'No requieres ayuno. Trae tu cepillo dental si deseas que te enseñemos la técnica ideal.',
    category: 'Preventivo'
  },
  {
    id: 't2',
    name: 'Curación de caries con resina estética',
    serviceId: 'operatoria',
    serviceName: 'Operatoria dental',
    symptoms: ['Mancha café o negra en muela', 'Diente picado', 'Sensibilidad al dulce', 'Diente astillado'],
    description: 'Limpieza minuciosa de la cavidad cariosa y colocación de resina fotocurable con pulido de alto brillo.',
    prepTip: 'Come ligero antes de tu cita. El procedimiento se realiza con anestesia local cómoda.',
    category: 'Restaurador'
  },
  {
    id: 't3',
    name: 'Tratamiento de encías sangrantes (Gingivitis)',
    serviceId: 'periodoncia',
    serviceName: 'Periodoncia',
    symptoms: ['Sangrado al cepillar', 'Encías rojas e inflamadas', 'Sensibilidad gingival', 'Gingivitis'],
    description: 'Raspado cuidadoso bajo el margen de la encía y descontaminación para devolver el tono rosado saludable a tu encía.',
    prepTip: 'Evita tomar aspirina previo a la cita. El sangrado disminuirá gradualmente tras la sesión.',
    category: 'Especialidades'
  },
  {
    id: 't4',
    name: 'Endodoncia para muela con dolor agudo',
    serviceId: 'endodoncia',
    serviceName: 'Endodoncia',
    symptoms: ['Dolor punzante de noche', 'Sensibilidad al calor insoportable', 'Infección en raíz', 'Dolor al masticar'],
    description: 'Extracción de la pulpa infectada, desinfección química de los conductos y obturación hermética que rescata la pieza.',
    prepTip: 'Si tienes radiografía previa llévala, de lo contrario te la tomamos en la clínica.',
    category: 'Especialidades'
  },
  {
    id: 't5',
    name: 'Extracción de muelas del juicio retenidas',
    serviceId: 'cirugia',
    serviceName: 'Cirugía bucal',
    symptoms: ['Dolor en parte trasera de la mandíbula', 'Hinchazón en mejilla', 'Muelas chuecas saliendo', 'Infección recurrente'],
    description: 'Cirugía menor con técnica aséptica, anestesia local profunda y retiro seguro de terceros molares.',
    prepTip: 'Asiste acompañado por un familiar. Se indicarán analgésicos y cuidados postoperatorios.',
    category: 'Quirúrgico'
  },
  {
    id: 't6',
    name: 'Corona dental fija de porcelana / zirconia',
    serviceId: 'protesis',
    serviceName: 'Prótesis dental',
    symptoms: ['Diente destruido', 'Diente con endodoncia previa', 'Falta de diente', 'Estética dental'],
    description: 'Funda dental resistente y biocompatible que protege la raíz y recrea la anatomía dental con apariencia idéntica a tus dientes naturales.',
    prepTip: 'Se toman impresiones digitales o de alta precisión para fabricarla en laboratorio dental.',
    category: 'Restaurador'
  },
  {
    id: 't7',
    name: 'Selladores y fluorización para niños',
    serviceId: 'odontopediatria',
    serviceName: 'Odontopediatría',
    symptoms: ['Molares de niños recién salidos', 'Prevención infantil', 'Dientes de leche', 'Primera visita al dentista'],
    description: 'Blindaje transparente sobre los surcos de las muelitas para impedir que la comida se quede atrapada y cause caries.',
    prepTip: 'Dile a tu peque que iremos a "contar y bañar sus dientitos" para que venga súper contento.',
    category: 'Infantil'
  },
  {
    id: 't8',
    name: 'Radiografía periapical digital diagnóstica',
    serviceId: 'radiologia',
    serviceName: 'Radiología dental',
    symptoms: ['Dolor no identificado', 'Revisión de raíz', 'Valoración para extracción', 'Detección de quistes'],
    description: 'Toma digital instantánea con baja radiación que se visualiza en monitor de alta definición en pocos segundos.',
    prepTip: 'Retira aretes, collares o pasadores metálicos antes de pasar al gabinete de rayos X.',
    category: 'Especialidades'
  },
  {
    id: 't9',
    name: 'Valoración para Brackets y Ortodoncia',
    serviceId: 'ortodoncia',
    serviceName: 'Ortodoncia',
    symptoms: ['Dientes apiñados', 'Dientes separados (diastemas)', 'Mordida chueca', 'Dificultad al cerrar la boca'],
    description: 'Estudio clínico completo con toma de modelos, fotografías intraorales y plan para alinear tu sonrisa con brackets.',
    prepTip: 'Ideal contar con boca libre de caries y sarro antes de iniciar la colocación de brackets.',
    category: 'Especialidades'
  }
];

export const SMILE_TIPS: SmileTip[] = [
  {
    id: 'tip-1',
    title: 'Técnica de cepillado Bass Modificada',
    category: 'Higiene Diaria',
    desc: 'Coloca el cepillo en un ángulo de 45° hacia la línea de la encía y realiza movimientos vibratorios suaves hacia el borde del diente. ¡Nunca frotes con fuerza horizontal!',
    action: 'Dedica 2 minutos completos, 3 veces al día.',
    sparkleEmoji: '✨'
  },
  {
    id: 'tip-2',
    title: 'El hilo dental es tu mejor aliado',
    category: 'Interdental',
    desc: 'El cepillo solo limpia el 60% de tus dientes. El hilo dental remueve la placa entre diente y diente, evitando la caries interproximal y el sangrado.',
    action: 'Úsalo todas las noches antes de acostarte.',
    sparkleEmoji: '💖'
  },
  {
    id: 'tip-3',
    title: 'Cambio de cepillo cada 3 meses',
    category: 'Herramientas',
    desc: 'Las cerdas dobladas o desgastadas pierden eficacia y pueden acumular bacterias. Si tuviste gripe o infección bucal, renuévalo de inmediato.',
    action: 'Elige siempre cerdas suaves o ultra suaves.',
    sparkleEmoji: '🌸'
  },
  {
    id: 'tip-4',
    title: 'Cuidado con las bebidas ácidas y azúcares',
    category: 'Nutrición',
    desc: 'Bebidas con limón, energizantes y refrescos desmineralizan el esmalte dental. Espera 20 minutos antes de cepillarte tras comer cosas muy ácidas.',
    action: 'Bebe agua pura después de cada comida.',
    sparkleEmoji: '💧'
  },
  {
    id: 'tip-5',
    title: 'No ignores la lengua al limpiarte',
    category: 'Frescura',
    desc: 'El 80% de las bacterias que causan mal aliento viven en la superficie de la lengua. Cepíllala suavemente de atrás hacia adelante con tu cepillo o raspador lingual.',
    action: 'Sensación fresca garantizada todo el día.',
    sparkleEmoji: '🎀'
  }
];

export const FAQS: FaqItem[] = [
  {
    question: '¿Quién atiende en las clínicas de la Facultad de Odontología?',
    answer: 'La atención es brindada por pasantes y estudiantes destacados de la Licenciatura de Cirujano Dentista y especialistas de posgrado, todos bajo la estricta y permanente supervisión de catedráticos odontólogos certificados con amplia trayectoria clínica.',
    category: 'Atención Clínica'
  },
  {
    question: '¿Cómo solicito una cita de primera vez?',
    answer: 'Debes presentarte en la Clínica Calafia de la Facultad de Odontología Mexicali o comunicarte al teléfono oficial 686 557 3268 o por correo a paulina.montelongo@uabc.edu.mx. Pasarás al área de Admisión y Diagnóstico para la apertura de expediente y valoración inicial.',
    category: 'Citas'
  },
  {
    question: '¿Cuáles son las cuotas de recuperación?',
    answer: 'Al ser una institución educativa pública de la UABC, nuestros servicios manejan cuotas de recuperación universitarias significativamente más accesibles que en consultorios privados, cubriendo únicamente los materiales e insumos de la más alta calidad.',
    category: 'Costos'
  },
  {
    question: '¿Qué documentos o requisitos debo llevar?',
    answer: 'Identificación oficial con fotografía (INE o equivalente), CURP, y en caso de menores de edad venir acompañados de madre, padre o tutor con acta de nacimiento. Trae además una lista de los medicamentos que tomes actualmente.',
    category: 'Requisitos'
  },
  {
    question: '¿Cuánto tiempo dura cada consulta clínica?',
    answer: 'Debido al minucioso protocolo universitario de revisión paso a paso por los profesores especialistas para garantizar la máxima calidad y seguridad, las citas suelen durar entre 45 y 90 minutos según el tratamiento.',
    category: 'Tiempos'
  },
  {
    question: '¿Qué medidas de higiene y esterilización siguen?',
    answer: 'Seguimos rigurosas normas oficiales de bioseguridad. Todo el instrumental pasa por ciclos de autoclave con controles biológicos, usamos barreras desechables y equipo de protección personal completo en cada paciente.',
    category: 'Seguridad'
  }
];

export const PATIENT_STEPS = [
  {
    step: 'Paso 1',
    title: 'Llegada y Admisión',
    desc: 'Acude a la recepción de la Clínica Calafia con tu identificación oficial. Se generará tu número de expediente clínico UABC.',
    badge: 'Apertura de Expediente'
  },
  {
    step: 'Paso 2',
    title: 'Valoración y Diagnóstico Integral',
    desc: 'Un profesor y alumno revisarán detalladamente tu cavidad oral, registrarán tu odontograma y tomarán radiografías si es necesario.',
    badge: 'Diagnóstico 360°'
  },
  {
    step: 'Paso 3',
    title: 'Propuesta de Plan y Cuotas',
    desc: 'Se te explicarán con claridad las alternativas de tratamiento, las fechas de tus citas y las cuotas de recuperación universitarias.',
    badge: 'Transparencia Total'
  },
  {
    step: 'Paso 4',
    title: 'Atención en Clínica Especializada',
    desc: 'Iniciarás tus citas en la clínica correspondiente (preventiva, operatoria, endodoncia, prótesis, etc.) con todo el cuidado que mereces.',
    badge: '¡Tu Sonrisa Renace!'
  }
];
