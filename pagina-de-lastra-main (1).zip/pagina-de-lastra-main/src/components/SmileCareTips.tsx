import React, { useState } from 'react';
import { SMILE_TIPS } from '../data/dentalData';
import { Sparkles, Heart, Check, Smile, Star, RefreshCw } from 'lucide-react';

export const SmileCareTips: React.FC = () => {
  const [completedRoutines, setCompletedRoutines] = useState<{ [key: string]: boolean }>({
    r1: true,
    r2: false,
    r3: false,
    r4: false,
  });

  const [activeMythTab, setActiveMythTab] = useState<number>(0);

  const toggleRoutine = (id: string) => {
    setCompletedRoutines((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const completedCount = Object.values(completedRoutines).filter(Boolean).length;

  const myths = [
    {
      myth: '“Cepillarse con mucha fuerza limpia mejor los dientes”',
      reality: '¡Falso! El cepillado agresivo desgasta el esmalte dental y hace que las encías se retraigan, provocando una dolorosa sensibilidad. Se requiere técnica suave y vibratoria.',
      cuteIcon: '✨'
    },
    {
      myth: '“Si mis encías sangran, debo dejar de pasar hilo dental”',
      reality: '¡Al contrario! Las encías sangran porque hay bacterias inflamándolas. El uso diario y suave del hilo dental desinflama y detiene el sangrado en pocos días.',
      cuteIcon: '🌸'
    },
    {
      myth: '“Las muelas de leche no importan porque se van a caer”',
      reality: '¡Completamente falso! Los dientes de leche guardan el espacio para los definitivos, permiten masticar y evitan infecciones graves que pueden dañar el diente permanente en formación.',
      cuteIcon: '🧸'
    },
    {
      myth: '“El bicarbonato y el limón son buenos blanqueadores caseros”',
      reality: '¡Peligroso! El limón es ácido y el bicarbonato es sumamente abrasivo; juntos rayan y disuelven el esmalte irreversiblemente. El blanqueamiento debe ser supervisado por tu dentista UABC.',
      cuteIcon: '💖'
    }
  ];

  return (
    <section id="consejos" className="py-14 sm:py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F8DDE8] text-[#D979A0] text-xs font-bold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5" />
            <span>Guía de Belleza y Salud Dental</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Consejos para cuidar tu <span className="text-[#D979A0]">sonrisa</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Hábitos sencillos y comprobados por los especialistas de la Facultad de Odontología UABC para lucir una dentadura sana, blanca y hermosa todos los días.
          </p>
        </div>

        {/* Top Cards: Educational Tips */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
          {SMILE_TIPS.map((tip) => (
            <div
              key={tip.id}
              className="p-6 rounded-3xl bg-[#FFF8FA] border border-[#F8DDE8] shadow-girly-sm hover:shadow-girly transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{tip.sparkleEmoji}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white text-[#D979A0] border border-[#E9AFC4]">
                    {tip.category}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#38333B] font-display">
                  {tip.title}
                </h3>

                <p className="text-xs text-[#59525C] leading-relaxed">
                  {tip.desc}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#F8DDE8] text-xs font-semibold text-[#D979A0] flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-[#E9AFC4] shrink-0" />
                <span>{tip.action}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Feature: Daily Smile Routine Checklist */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-gradient-to-r from-[#F8DDE8] via-[#FFFFFF] to-[#E9E1F5] p-6 sm:p-10 rounded-3xl border border-[#E9AFC4]/60 shadow-girly">
          
          <div className="lg:col-span-6 space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-[#D979A0] text-xs font-bold shadow-sm">
              <Star className="w-3.5 h-3.5 text-[#D979A0]" />
              <span>Tu Reto Girly Diario</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#38333B] font-display">
              Mi Rutina de Sonrisa Brillante ✨
            </h3>

            <p className="text-xs sm:text-sm text-[#59525C] leading-relaxed">
              Marca las metas de hoy para mantener tus dientes impecables. ¡Una rutina constante es el mejor tratamiento preventivo!
            </p>

            {/* Progress counter */}
            <div className="p-4 rounded-2xl bg-white/90 border border-[#F8DDE8] flex items-center justify-between">
              <div>
                <span className="text-xs text-[#777078] font-medium">Progreso del día:</span>
                <p className="text-lg font-extrabold text-[#D979A0]">
                  {completedCount} de 4 hábitos completados
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#FFF0F5] border-2 border-[#E9AFC4] flex items-center justify-center font-bold text-sm text-[#D979A0]">
                {Math.round((completedCount / 4) * 100)}%
              </div>
            </div>

            {completedCount === 4 && (
              <div className="p-3.5 rounded-2xl bg-[#E9E1F5] text-[#5C4D7D] text-xs font-bold border border-[#D5C6EC] flex items-center gap-2 animate-bounce">
                <span>🎉</span>
                <span>¡Felicidades, reina! Tu sonrisa está radiante y protegida hoy.</span>
              </div>
            )}
          </div>

          {/* Interactive Checkbox Items */}
          <div className="lg:col-span-6 space-y-3">
            {[
              { id: 'r1', label: 'Cepillado matutino de 2 minutos (técnica circular)', time: 'Al despertar' },
              { id: 'r2', label: 'Limpieza con hilo dental entre cada diente', time: 'Noche o tras comer' },
              { id: 'r3', label: 'Limpieza suave de lengua y enjuague con agua', time: 'Mañana y noche' },
              { id: 'r4', label: 'Cepillado nocturno sagrado antes de ir a dormir', time: 'Antes de dormir' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => toggleRoutine(item.id)}
                className={`w-full p-4 rounded-2xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                  completedRoutines[item.id]
                    ? 'bg-white border-[#D979A0] shadow-girly-sm'
                    : 'bg-white/70 border-[#F8DDE8] hover:bg-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors ${
                      completedRoutines[item.id]
                        ? 'bg-[#D979A0] text-white'
                        : 'border border-[#E9AFC4] bg-[#FFF8FA]'
                    }`}
                  >
                    {completedRoutines[item.id] && <Check className="w-4 h-4 stroke-[3]" />}
                  </div>
                  <div>
                    <p
                      className={`text-xs sm:text-sm font-bold ${
                        completedRoutines[item.id] ? 'text-[#38333B] line-through opacity-70' : 'text-[#38333B]'
                      }`}
                    >
                      {item.label}
                    </p>
                    <span className="text-[10px] text-[#777078] font-medium">{item.time}</span>
                  </div>
                </div>
                <span className="text-base">{completedRoutines[item.id] ? '💖' : '🤍'}</span>
              </button>
            ))}
          </div>

        </div>

        {/* Myths vs Realities Section */}
        <div className="mt-14 space-y-6">
          <div className="text-center space-y-1">
            <h3 className="text-xl sm:text-2xl font-bold text-[#38333B] font-display">
              Mitos vs. Realidades en Odontología 🔍
            </h3>
            <p className="text-xs text-[#777078]">
              Aprende a diferenciar las recomendaciones científicas de las creencias populares.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myths.map((item, idx) => (
              <div
                key={idx}
                className="p-5 rounded-3xl bg-[#FFF8FA] border border-[#F8DDE8] shadow-sm hover:border-[#E9AFC4] transition-all space-y-3"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{item.cuteIcon}</span>
                  <p className="text-xs sm:text-sm font-bold text-[#D979A0]">
                    {item.myth}
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white border border-[#F8DDE8] text-xs text-[#4A454D] leading-relaxed">
                  <strong className="text-[#38333B] block mb-1">La realidad científica:</strong>
                  {item.reality}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
