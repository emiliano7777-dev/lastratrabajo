import React from 'react';
import { Home, Sparkles, Search, UserCheck, PhoneCall } from 'lucide-react';

interface MobileTabBarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const MobileTabBar: React.FC<MobileTabBarProps> = ({ activeSection, onNavigate }) => {
  const tabs = [
    { id: 'inicio', label: 'Inicio', icon: Home },
    { id: 'servicios', label: 'Servicios', icon: Sparkles },
    { id: 'buscador', label: 'Buscar', icon: Search },
    { id: 'pacientes', label: 'Pacientes', icon: UserCheck },
    { id: 'contacto', label: 'Contacto', icon: PhoneCall },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#F8DDE8] shadow-[0_-4px_20px_rgba(217,121,160,0.12)]">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1">
        {tabs.map((tab) => {
          const isActive = activeSection === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-all cursor-pointer ${
                isActive ? 'text-[#D979A0]' : 'text-[#777078] hover:text-[#D979A0]'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive ? 'bg-[#FFF0F5] scale-110' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span
                className={`text-[10px] font-semibold mt-0.5 tracking-tight ${
                  isActive ? 'font-bold text-[#D979A0]' : ''
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
