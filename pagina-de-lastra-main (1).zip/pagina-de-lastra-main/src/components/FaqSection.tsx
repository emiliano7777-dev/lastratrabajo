import React, { useState } from 'react';
import { FAQS, INSTITUTIONAL_INFO } from '../data/dentalData';
import { HelpCircle, ChevronDown, Sparkles, Phone, Mail } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-14 sm:py-20 bg-white relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F8DDE8] text-[#D979A0] text-xs font-bold uppercase tracking-wider">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Resolvemos tus dudas</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Preguntas <span className="text-[#D979A0]">frecuentes</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Información transparente para que asistas con total tranquilidad a tu consulta odontológica.
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className={`rounded-2xl border transition-all overflow-hidden ${
                  isOpen
                    ? 'bg-[#FFF8FA] border-[#E9AFC4] shadow-girly-sm'
                    : 'bg-white border-[#F8DDE8] hover:border-[#E9AFC4]/50'
                }`}
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-base">🌸</span>
                    <span className="text-xs sm:text-sm font-bold text-[#38333B]">
                      {faq.question}
                    </span>
                  </div>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-[#D979A0] text-white' : 'bg-[#FFF0F5] text-[#D979A0]'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#59525C] leading-relaxed border-t border-[#F8DDE8]/60 animate-in fade-in duration-200">
                    <div className="p-3.5 rounded-xl bg-white border border-[#F8DDE8] shadow-sm">
                      {faq.answer}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Small Assistance Box */}
        <div className="mt-10 p-5 rounded-2xl bg-gradient-to-r from-[#F8DDE8] via-white to-[#E9E1F5] border border-[#E9AFC4] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <Sparkles className="w-5 h-5 text-[#D979A0] shrink-0" />
            <span className="text-[#4A454D] font-medium">
              ¿Tienes alguna duda específica que no aparezca aquí? Llámanos directamente:
            </span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
              className="px-4 py-2 rounded-full bg-[#D979A0] text-white font-bold hover:bg-[#C26289] transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{INSTITUTIONAL_INFO.phone}</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
