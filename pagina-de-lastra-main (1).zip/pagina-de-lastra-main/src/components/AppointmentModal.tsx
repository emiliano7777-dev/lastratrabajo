import React, { useState } from 'react';
import { INSTITUTIONAL_INFO, DENTAL_SERVICES } from '../data/dentalData';
import { X, Sparkles, Phone, Mail, MapPin, Send, CheckCircle2 } from 'lucide-react';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultServiceName?: string;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  defaultServiceName,
}) => {
  const [name, setName] = useState('');
  const [selectedService, setSelectedService] = useState(defaultServiceName || 'Odontología preventiva');
  const [preferredShift, setPreferredShift] = useState('Matutino (8:00 AM - 12:00 PM)');
  const [notes, setNotes] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Solicitud de Cita ODOCARE UABC - ${selectedService} - ${name || 'Paciente'}`);
    const body = encodeURIComponent(
      `Hola Facultad de Odontología UABC Mexicali:\n\n` +
      `Nombre del Paciente: ${name || 'Sin especificar'}\n` +
      `Servicio solicitado: ${selectedService}\n` +
      `Turno preferente: ${preferredShift}\n` +
      `Motivo / Síntomas: ${notes || 'Valoración general de primera vez'}\n\n` +
      `Solicito información para acudir a la Clínica Calafia.\n` +
      `¡Muchas gracias!`
    );

    window.location.href = `mailto:${INSTITUTIONAL_INFO.email}?subject=${subject}&body=${body}`;
    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#F8DDE8] overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#F8DDE8] via-[#E9AFC4] to-[#E9E1F5] p-4 flex items-center justify-between text-[#38333B]">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-white/80 flex items-center justify-center text-[#D979A0]">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-[#38333B]">
                Solicitar Cita / Informes
              </h3>
              <p className="text-[10px] text-[#777078]">
                Clínica Calafia · UABC Mexicali
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/80 hover:bg-white text-[#777078] hover:text-[#D979A0] flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Quick Call Reminder */}
          <div className="p-3 rounded-2xl bg-[#FFF8FA] border border-[#E9AFC4] flex items-center justify-between text-xs">
            <span className="text-[#59525C] font-medium">¿Prefieres agendar por teléfono?</span>
            <a
              href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
              className="font-bold text-[#D979A0] hover:underline flex items-center gap-1"
            >
              <Phone className="w-3.5 h-3.5" />
              {INSTITUTIONAL_INFO.phone}
            </a>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#38333B] mb-1">
              Nombre de la/el paciente:
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej. Valeria López González"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#38333B] mb-1">
              Servicio Odontológico:
            </label>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
            >
              {DENTAL_SERVICES.map((serv) => (
                <option key={serv.id} value={serv.name}>
                  {serv.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-[#38333B]">
                Turno de preferencia:
              </label>
              <span className="text-[10px] text-[#D979A0] font-semibold">
                Lunes a Viernes (8 AM - 4 PM)
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {['Matutino (8:00 AM - 12:00 PM)', 'Vespertino (12:00 PM - 4:00 PM)'].map((shift) => (
                <button
                  type="button"
                  key={shift}
                  onClick={() => setPreferredShift(shift)}
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                    preferredShift === shift
                      ? 'bg-[#FFF0F5] border-[#D979A0] text-[#D979A0] font-bold'
                      : 'bg-[#FFF8FA] border-[#F8DDE8] text-[#777078]'
                  }`}
                >
                  {shift}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-[#777078] mt-1 italic">
              *Atención exclusivamente entre semana de 8:00 AM a 4:00 PM. Fines de semana cerrado.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#38333B] mb-1">
              Notas adicionales (opcional):
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="¿Tienes dolor, alguna duda o antecedente que debamos saber?"
              className="w-full px-3.5 py-2 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
            />
          </div>

          {sentSuccess && (
            <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Preparando correo... ¡Gracias por confiar en ODOCARE UABC!</span>
            </div>
          )}

          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-2.5 rounded-full bg-white border border-[#F8DDE8] text-xs font-semibold text-[#777078] hover:text-[#D979A0] cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="w-2/3 py-2.5 rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs font-bold shadow-girly hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Enviar al Correo Oficial</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
