import React from 'react';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import { MapPin, Phone, Mail, Navigation, ExternalLink, Clock, Car, Bus, Sparkles } from 'lucide-react';

export const LocationSection: React.FC = () => {
  return (
    <section id="ubicacion" className="py-14 sm:py-20 bg-[#FFF8FA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E9E1F5] text-[#5C4D7D] text-xs font-bold uppercase tracking-wider">
            <MapPin className="w-3.5 h-3.5 text-[#8869B3]" />
            <span>Campus Mexicali · Fraccionamiento Calafia</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Ubicación y cómo <span className="text-[#D979A0]">llegar</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Encuéntranos en las instalaciones oficiales de la Clínica Calafia de la Facultad de Odontología UABC en Mexicali, Baja California.
          </p>
        </div>

        {/* Main Grid: Card with Façade Photo + Detailed Transit/Official Link */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Clinic Calafia Visual */}
          <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-[#F8DDE8] shadow-girly flex flex-col justify-between space-y-4">
            <div className="space-y-4">
              <div className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-[#E9AFC4] bg-[#F8DDE8] shadow-sm">
                <img
                  src={INSTITUTIONAL_INFO.clinicFacadePhoto}
                  alt="Fachada de la Clínica Calafia Facultad de Odontología UABC"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-white/95 px-3 py-1 rounded-full text-xs font-bold text-[#D979A0] shadow-sm flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#D979A0]" />
                  <span>Edificio Clínica Calafia</span>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-[#38333B] font-display">
                  {INSTITUTIONAL_INFO.clinicName}
                </h3>
                <p className="text-xs text-[#777078] mt-1 flex items-start gap-1.5">
                  <MapPin className="w-4 h-4 text-[#D979A0] shrink-0 mt-0.5" />
                  <span>{INSTITUTIONAL_INFO.address}</span>
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="p-3 rounded-2xl bg-[#FFF8FA] border border-[#F8DDE8]">
                  <strong className="text-[#38333B] block mb-1 flex items-center gap-1.5 font-bold">
                    <Car className="w-3.5 h-3.5 text-[#D979A0]" />
                    En vehículo particular:
                  </strong>
                  <p className="text-[#59525C] text-[11px] leading-relaxed">
                    Fácil acceso por Calzada Independencia y Blvd. Benito Juárez, entrando por Fracc. Calafia. Estacionamiento universitario disponible.
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-[#FFF8FA] border border-[#F8DDE8]">
                  <strong className="text-[#38333B] block mb-1 flex items-center gap-1.5 font-bold">
                    <Bus className="w-3.5 h-3.5 text-[#D979A0]" />
                    En transporte público:
                  </strong>
                  <p className="text-[#59525C] text-[11px] leading-relaxed">
                    Rutas de transporte colectivo hacia el Centro Cívico y UABC Central con parada a pocos pasos de la Clínica Calafia.
                  </p>
                </div>
              </div>
            </div>

            {/* Prominent "Cómo llegar" button */}
            <div className="pt-4 border-t border-[#F8DDE8] flex flex-col sm:flex-row items-center gap-3">
              <a
                href={INSTITUTIONAL_INFO.howToGetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:flex-1 py-3 px-4 rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] hover:opacity-95 text-white text-xs sm:text-sm font-bold shadow-girly transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Navigation className="w-4 h-4" />
                <span>Cómo llegar (Google Maps)</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>

              <a
                href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                className="w-full sm:w-auto py-3 px-4 rounded-full bg-white border border-[#E9AFC4] text-[#D979A0] text-xs font-bold hover:bg-[#FFF0F5] transition-all flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Phone className="w-4 h-4" />
                <span>{INSTITUTIONAL_INFO.phone}</span>
              </a>
            </div>
          </div>

          {/* Right Column: Interactive Map Preview Card & Hours */}
          <div className="lg:col-span-6 space-y-6 flex flex-col justify-between">
            
            {/* Visual Location Guide Card */}
            <div className="bg-white p-6 rounded-3xl border border-[#F8DDE8] shadow-girly space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#D979A0]">
                  Referencias Geográficas
                </span>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#E9E1F5] text-[#5C4D7D]">
                  Mexicali, B.C.
                </span>
              </div>

              {/* Stylized visual map plate */}
              <div className="h-52 rounded-2xl bg-gradient-to-br from-[#F8DDE8] via-[#FFF8FA] to-[#E9E1F5] p-5 border border-[#E9AFC4]/50 flex flex-col justify-between relative overflow-hidden">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-xs font-bold text-[#D979A0] shadow-sm">
                    <MapPin className="w-3.5 h-3.5 text-[#D979A0]" />
                    <span>Facultad de Odontología UABC</span>
                  </div>
                  <p className="text-xs text-[#59525C] font-semibold pt-1">
                    Av. Zotoluca y Chinampas S/N, Fraccionamiento Calafia
                  </p>
                </div>

                <div className="bg-white/90 backdrop-blur-md p-3 rounded-2xl border border-[#F8DDE8] text-xs space-y-1">
                  <p className="font-bold text-[#38333B]">Puntos de referencia cercanos:</p>
                  <p className="text-[11px] text-[#777078]">
                    • Zona Centro Cívico de Mexicali (a 3 minutos)
                  </p>
                  <p className="text-[11px] text-[#777078]">
                    • Calzada Independencia & Blvd. Anáhuac
                  </p>
                </div>

                {/* Floating Pin animation */}
                <div className="absolute right-6 top-8 w-12 h-12 rounded-full bg-[#D979A0]/20 flex items-center justify-center animate-pulse">
                  <div className="w-8 h-8 rounded-full bg-[#D979A0] text-white flex items-center justify-center shadow-lg">
                    <MapPin className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* Contact directly via email */}
              <div className="p-4 rounded-2xl bg-[#FFF8FA] border border-[#F8DDE8] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-bold text-[#38333B] block">Correo institucional oficial:</span>
                  <span className="text-[#777078]">{INSTITUTIONAL_INFO.email}</span>
                </div>
                <a
                  href={`mailto:${INSTITUTIONAL_INFO.email}`}
                  className="px-4 py-2 rounded-full bg-white border border-[#E9AFC4] text-[#D979A0] font-bold hover:bg-[#FFF0F5] transition-all flex items-center gap-1.5 shrink-0"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Escribir Correo</span>
                </a>
              </div>
            </div>

            {/* Phone Caution Pill */}
            <div className="p-4 rounded-2xl bg-[#E9E1F5]/70 border border-[#D5C6EC] text-xs text-[#5C4D7D] flex items-center gap-3">
              <span className="text-xl">📞</span>
              <div>
                <strong className="block font-bold">Línea Telefónica Exclusiva UABC:</strong>
                Para informes de citas, turnos y admisiones, comunícate únicamente al <strong>{INSTITUTIONAL_INFO.phone}</strong>.
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
