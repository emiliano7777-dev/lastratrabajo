import React, { useState } from 'react';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import { Phone, Mail, MapPin, Sparkles, Menu, X, Facebook } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenAppointmentModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, onNavigate, onOpenAppointmentModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'inicio', label: 'Inicio' },
    { id: 'servicios', label: 'Servicios' },
    { id: 'buscador', label: 'Buscador' },
    { id: 'consejos', label: 'Cuidado Dental' },
    { id: 'pacientes', label: 'Pacientes' },
    { id: 'tecnologia', label: 'Tecnología' },
    { id: 'ubicacion', label: 'Ubicación' },
    { id: 'contacto', label: 'Contacto' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#FFFFFF]/90 backdrop-blur-md border-b border-[#F8DDE8]">
      {/* Top Banner Ribbon */}
      <div className="bg-gradient-to-r from-[#F8DDE8] via-[#E9AFC4] to-[#E9E1F5] text-[#4A454D] text-xs py-1.5 px-4 font-medium flex items-center justify-between">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-sm">🌸</span>
            <span className="font-semibold tracking-tight">Facultad de Odontología UABC Mexicali</span>
            <span className="hidden sm:inline text-[#777078]">· Atención con calidez universitaria</span>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <a
              href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
              className="flex items-center gap-1.5 text-[#D979A0] hover:text-[#9A4168] transition-colors"
              title="Teléfono oficial de la clínica"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{INSTITUTIONAL_INFO.phone}</span>
            </a>
            <span className="hidden md:inline text-[#E9AFC4]">|</span>
            <a
              href={INSTITUTIONAL_INFO.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:flex items-center gap-1 text-[#4A454D] hover:text-[#D979A0] transition-colors"
            >
              <Facebook className="w-3 h-3 text-[#1877F2]" />
              <span>Facebook Oficial</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo & Brand Zone */}
          <button
            onClick={() => handleLinkClick('inicio')}
            className="flex items-center gap-3 text-left group cursor-pointer focus:outline-none"
          >
            <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-[#E9AFC4] shadow-girly-sm p-0.5 bg-[#FFFFFF] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <img
                src={INSTITUTIONAL_INFO.principalLogo}
                alt="Logo FOM UABC"
                className="w-full h-full object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xl font-extrabold tracking-tight text-[#D979A0] font-display">
                  ODOCARE
                </span>
                <span className="text-xs font-bold px-1.5 py-0.5 rounded-md bg-[#F8DDE8] text-[#777078] tracking-wider">
                  UABC
                </span>
              </div>
              <p className="text-[11px] text-[#777078] font-medium leading-none mt-0.5">
                Facultad de Odontología · Mexicali
              </p>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#FFF8FA] p-1.5 rounded-full border border-[#F8DDE8]">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white shadow-girly-sm'
                      : 'text-[#777078] hover:text-[#D979A0] hover:bg-[#F8DDE8]/50'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons Zone */}
          <div className="hidden sm:flex items-center gap-2.5">
            <a
              href={INSTITUTIONAL_INFO.howToGetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-full bg-[#E9E1F5] text-[#5C4D7D] hover:bg-[#D5C6EC] transition-all cursor-pointer shadow-sm"
            >
              <MapPin className="w-3.5 h-3.5 text-[#8869B3]" />
              <span>Cómo llegar</span>
            </a>

            <button
              onClick={onOpenAppointmentModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white hover:opacity-95 transition-all shadow-girly hover:scale-102 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Pedir Informes</span>
            </button>
          </div>

          {/* Mobile Menu Hamburger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onOpenAppointmentModal}
              className="p-2 rounded-full bg-[#F8DDE8] text-[#D979A0] hover:bg-[#E9AFC4]/40"
              aria-label="Cita rápida"
            >
              <Sparkles className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-[#777078] hover:text-[#D979A0]"
              aria-label="Abrir menú"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/98 border-b border-[#F8DDE8] px-4 pt-3 pb-6 space-y-3 shadow-lg animate-in slide-in-from-top-4 duration-200">
          <div className="grid grid-cols-2 gap-2 pt-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`px-3 py-2 text-left text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                  activeSection === link.id
                    ? 'bg-[#F8DDE8] text-[#D979A0] font-bold'
                    : 'text-[#777078] hover:bg-[#FFF8FA]'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-[#F8DDE8] space-y-2">
            <a
              href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#FFF0F5] text-[#D979A0] font-bold text-xs border border-[#F8DDE8]"
            >
              <Phone className="w-4 h-4" />
              <span>Llamar a Clínica ({INSTITUTIONAL_INFO.phone})</span>
            </a>

            <a
              href={INSTITUTIONAL_INFO.howToGetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#E9E1F5] text-[#5C4D7D] font-bold text-xs"
            >
              <MapPin className="w-4 h-4" />
              <span>Cómo llegar (Sitio Oficial FOM)</span>
            </a>

            <a
              href={`mailto:${INSTITUTIONAL_INFO.email}`}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#F8DDE8] text-[#4A454D] font-medium text-xs"
            >
              <Mail className="w-4 h-4 text-[#D979A0]" />
              <span>{INSTITUTIONAL_INFO.email}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
