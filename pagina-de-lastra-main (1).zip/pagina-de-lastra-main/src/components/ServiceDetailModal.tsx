import React from 'react';
import { DentalService } from '../types';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import {
  X,
  Sparkles,
  Clock,
  CheckCircle2,
  Phone,
  Mail,
  Heart,
  Smile,
  HeartPulse,
  ShieldCheck,
  Scissors,
  Layers,
  Baby,
  ScanLine,
  Star
} from 'lucide-react';

interface ServiceDetailModalProps {
  service: DentalService | null;
  onClose: () => void;
  onOpenAppointmentModal: (serviceName?: string) => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({
  service,
  onClose,
  onOpenAppointmentModal,
}) => {
  if (!service) return null;

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-8 h-8 text-[#D979A0]" />;
      case 'Smile':
        return <Smile className="w-8 h-8 text-[#D979A0]" />;
      case 'HeartPulse':
        return <HeartPulse className="w-8 h-8 text-[#D979A0]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-8 h-8 text-[#D979A0]" />;
      case 'Scissors':
        return <Scissors className="w-8 h-8 text-[#D979A0]" />;
      case 'Layers':
        return <Layers className="w-8 h-8 text-[#D979A0]" />;
      case 'Baby':
        return <Baby className="w-8 h-8 text-[#D979A0]" />;
      case 'ScanLine':
        return <ScanLine className="w-8 h-8 text-[#D979A0]" />;
      case 'Star':
        return <Star className="w-8 h-8 text-[#D979A0]" />;
      default:
        return <Sparkles className="w-8 h-8 text-[#D979A0]" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#F8DDE8] overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
        
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#F8DDE8] via-[#E9AFC4] to-[#E9E1F5] p-4 flex items-center justify-between text-[#38333B]">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-white/80 flex items-center justify-center text-[#D979A0]">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-[#777078]">
              Facultad de Odontología UABC Mexicali
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/80 hover:bg-white text-[#777078] hover:text-[#D979A0] flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Main Title & Girly Thematic Header */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-[#FFF0F5] via-[#F8DDE8]/50 to-[#E9E1F5]/60 border border-[#E9AFC4]/60 flex flex-col sm:flex-row items-center gap-5">
            <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl bg-white border-2 border-[#E9AFC4] shadow-girly-sm flex items-center justify-center shrink-0">
              {getServiceIcon(service.iconName)}
            </div>

            <div className="space-y-1 text-center sm:text-left flex-1">
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white text-[#D979A0] border border-[#E9AFC4] uppercase tracking-wider inline-block">
                {service.category} · UABC Mexicali
              </span>
              <h2 className="text-2xl font-extrabold text-[#38333B] font-display">
                {service.name}
              </h2>
              <p className="text-xs font-semibold text-[#D979A0] italic">
                "{service.cuteQuote}"
              </p>
              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs text-[#777078] pt-1">
                <Clock className="w-4 h-4 text-[#D979A0]" />
                <span>Duración estimada: <strong>{service.sessionDuration}</strong></span>
              </div>
            </div>
          </div>

          {/* Full Description */}
          <div className="bg-[#FFF8FA] p-4 rounded-2xl border border-[#F8DDE8]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#D979A0] mb-1.5 flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5" />
              ¿En qué consiste este servicio especializado?
            </h3>
            <p className="text-sm text-[#59525C] leading-relaxed">
              {service.fullDesc}
            </p>
          </div>

          {/* Treatments included */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-[#38333B] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#D979A0]" />
              Procedimientos y tratamientos realizados en la clínica:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {service.commonTreatments.map((treatment, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2 p-2.5 rounded-xl bg-white border border-[#F8DDE8] text-xs text-[#4A454D]"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#D979A0] shrink-0 mt-0.5" />
                  <span>{treatment}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Who is it recommended for */}
          <div className="p-3.5 rounded-2xl bg-[#E9E1F5]/60 border border-[#E9E1F5] text-xs space-y-1">
            <span className="font-bold text-[#5C4D7D] block">¿Para quién está recomendado?</span>
            <p className="text-[#59525C]">{service.recommendedFor}</p>
          </div>

          {/* Institutional Contact Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#FFF0F5] to-[#FFFFFF] border border-[#E9AFC4] flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold text-[#D979A0]">¿Deseas atenderte en este servicio?</p>
              <p className="text-xs text-[#777078]">
                Llama a la clínica al <strong className="text-[#38333B]">{INSTITUTIONAL_INFO.phone}</strong> o escribe a{' '}
                <strong className="text-[#38333B]">{INSTITUTIONAL_INFO.email}</strong>
              </p>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <a
                href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-white border border-[#E9AFC4] text-[#D979A0] text-xs font-bold hover:bg-[#FFF0F5] flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Llamar</span>
              </a>
              <button
                onClick={() => {
                  onClose();
                  onOpenAppointmentModal(service.name);
                }}
                className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs font-bold hover:opacity-95 shadow-girly flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Pedir Cita</span>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#FFF8FA] border-t border-[#F8DDE8] flex items-center justify-between">
          <span className="text-[11px] text-[#777078]">
            Facultad de Odontología UABC · Clínica Calafia
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-full bg-white border border-[#F8DDE8] text-xs font-semibold text-[#777078] hover:text-[#D979A0] cursor-pointer"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
};
