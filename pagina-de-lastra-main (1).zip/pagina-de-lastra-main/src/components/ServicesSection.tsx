import React, { useState } from 'react';
import { DentalService } from '../types';
import { DENTAL_SERVICES, INSTITUTIONAL_INFO, INSTITUTIONAL_GALLERY } from '../data/dentalData';
import {
  Sparkles,
  ArrowRight,
  Heart,
  Check,
  Clock,
  Phone,
  Info,
  Smile,
  HeartPulse,
  ShieldCheck,
  Scissors,
  Layers,
  Baby,
  ScanLine,
  Star,
  Camera
} from 'lucide-react';

interface ServicesSectionProps {
  onSelectService: (service: DentalService) => void;
  onOpenAppointmentModal: (serviceName?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectService,
  onOpenAppointmentModal,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('todos');

  const filterTabs = [
    { id: 'todos', label: 'Todos los servicios' },
    { id: 'preventivo', label: 'Preventivos' },
    { id: 'restaurador', label: 'Restauradores' },
    { id: 'especialidad', label: 'Especialidades' },
    { id: 'quirurgico', label: 'Quirúrgicos' },
    { id: 'infantil', label: 'Odontopediatría' },
  ];

  const filteredServices = selectedFilter === 'todos'
    ? DENTAL_SERVICES
    : DENTAL_SERVICES.filter(s => s.category === selectedFilter);

  // Icon mapping for each service card
  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-7 h-7 text-[#D979A0]" />;
      case 'Smile':
        return <Smile className="w-7 h-7 text-[#D979A0]" />;
      case 'HeartPulse':
        return <HeartPulse className="w-7 h-7 text-[#D979A0]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-7 h-7 text-[#D979A0]" />;
      case 'Scissors':
        return <Scissors className="w-7 h-7 text-[#D979A0]" />;
      case 'Layers':
        return <Layers className="w-7 h-7 text-[#D979A0]" />;
      case 'Baby':
        return <Baby className="w-7 h-7 text-[#D979A0]" />;
      case 'ScanLine':
        return <ScanLine className="w-7 h-7 text-[#D979A0]" />;
      case 'Star':
        return <Star className="w-7 h-7 text-[#D979A0]" />;
      default:
        return <Sparkles className="w-7 h-7 text-[#D979A0]" />;
    }
  };

  return (
    <section id="servicios" className="py-14 sm:py-20 bg-gradient-to-b from-[#FFF8FA] via-[#FFFFFF] to-[#FFF8FA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F8DDE8] text-[#D979A0] text-xs font-bold tracking-wider uppercase border border-[#E9AFC4]/40">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Atención Odontológica UABC</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Muchos servicios <span className="text-[#D979A0]">especializados</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078] leading-relaxed">
            Presentamos la oferta completa de servicios odontológicos de la Facultad de Odontología UABC en Mexicali. Cada área cuenta con supervisión de profesores especialistas y cuotas de recuperación accesibles.
          </p>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 pt-3">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedFilter(tab.id)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-all cursor-pointer ${
                  selectedFilter === tab.id
                    ? 'bg-[#D979A0] text-white shadow-girly-sm'
                    : 'bg-white text-[#777078] border border-[#F8DDE8] hover:border-[#E9AFC4] hover:text-[#D979A0]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 9 Services Grid (Girly, delicate card design without mismatched photos) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group bg-white rounded-3xl border border-[#F8DDE8] shadow-girly-sm shadow-girly-hover flex flex-col justify-between overflow-hidden transition-all duration-300 relative"
            >
              {/* Cute Header Card Gradient with Minimalist Girly Icon & Sparkles */}
              <div className="p-6 bg-gradient-to-br from-[#FFF0F5] via-[#F8DDE8]/50 to-[#E9E1F5]/40 border-b border-[#F8DDE8] flex items-center justify-between relative overflow-hidden">
                <div className="w-14 h-14 rounded-2xl bg-white/90 backdrop-blur-sm border border-[#E9AFC4] shadow-sm flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  {getServiceIcon(service.iconName)}
                </div>

                <div className="text-right space-y-1">
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-white text-[#D979A0] border border-[#E9AFC4] shadow-sm uppercase tracking-wider">
                    {service.category}
                  </span>
                  <p className="text-[11px] font-medium text-[#777078] flex items-center justify-end gap-1">
                    <Clock className="w-3 h-3 text-[#D979A0]" />
                    {service.sessionDuration}
                  </p>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="text-lg sm:text-xl font-bold text-[#38333B] group-hover:text-[#D979A0] transition-colors font-display">
                    {service.name}
                  </h3>

                  <p className="text-xs text-[#D979A0] font-semibold italic">
                    "{service.cuteQuote}"
                  </p>

                  <p className="text-xs sm:text-sm text-[#59525C] leading-relaxed">
                    {service.shortDesc}
                  </p>

                  {/* Highlights checklist */}
                  <div className="pt-3 space-y-1.5 border-t border-[#F8DDE8]/60">
                    <span className="text-[11px] font-bold text-[#777078] block">
                      Procedimientos frecuentes:
                    </span>
                    {service.commonTreatments.slice(0, 3).map((item, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-xs text-[#777078]">
                        <Check className="w-3.5 h-3.5 text-[#D979A0] shrink-0" />
                        <span className="truncate">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Duration & Actions */}
                <div className="pt-4 border-t border-[#F8DDE8] space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#777078]">
                    <span className="text-[11px] font-medium text-[#777078]">
                      {service.recommendedFor}
                    </span>
                    <span className="text-[11px] font-bold text-[#D979A0] shrink-0 ml-2">
                      UABC Mexicali
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onSelectService(service)}
                      className="px-3 py-2 rounded-xl bg-[#FFF8FA] hover:bg-[#F8DDE8] border border-[#F8DDE8] text-[#D979A0] text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Info className="w-3.5 h-3.5" />
                      <span>Ver detalles</span>
                    </button>

                    <button
                      onClick={() => onOpenAppointmentModal(service.name)}
                      className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] hover:opacity-95 text-white text-xs font-bold shadow-sm transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      <span>Pedir cita</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

              </div>
            </div>
          ))}
        </div>

        {/* Decorative Institutional Gallery Strip: user's photos shown in their genuine institutional beauty */}
        <div className="mt-16 pt-12 border-t border-[#F8DDE8] space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E9E1F5] text-[#5C4D7D] text-xs font-bold uppercase tracking-wider">
              <Camera className="w-3.5 h-3.5 text-[#8869B3]" />
              <span>Nuestra Facultad en Imágenes</span>
            </div>
            <h3 className="text-2xl font-bold text-[#38333B] font-display">
              Instalaciones, docencia y vida universitaria FOM UABC
            </h3>
            <p className="text-xs text-[#777078]">
              Fotografías institucionales que reflejan el compromiso, la calidez y los 50 años de trayectoria de la Facultad de Odontología en Mexicali.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {INSTITUTIONAL_GALLERY.map((item, idx) => (
              <div
                key={idx}
                className="group relative rounded-2xl overflow-hidden border border-[#E9AFC4]/70 bg-white shadow-girly-sm aspect-square"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-90 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-2.5 text-white">
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-[#D979A0] self-start mb-0.5">
                    {item.tag}
                  </span>
                  <p className="text-[11px] font-bold leading-tight truncate">
                    {item.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="mt-12 p-6 rounded-3xl bg-gradient-to-r from-[#F8DDE8] via-[#FFFFFF] to-[#E9E1F5] border border-[#E9AFC4]/50 shadow-girly flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-[#D979A0] shrink-0 shadow-sm border border-[#E9AFC4]">
              <Phone className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#38333B]">
                ¿Tienes dudas sobre cuál de nuestros servicios especializados necesitas?
              </h4>
              <p className="text-xs text-[#777078]">
                Llámanos al único teléfono oficial: <strong className="text-[#D979A0]">{INSTITUTIONAL_INFO.phone}</strong> para orientarte en Admisión.
              </p>
            </div>
          </div>

          <a
            href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
            className="px-5 py-2.5 rounded-full bg-[#D979A0] text-white text-xs font-bold shadow-girly hover:bg-[#C26289] transition-all cursor-pointer whitespace-nowrap"
          >
            Llamar al {INSTITUTIONAL_INFO.phone}
          </a>
        </div>

      </div>
    </section>
  );
};
