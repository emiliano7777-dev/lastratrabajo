import React from 'react';
import { INSTITUTIONAL_INFO, PATIENT_STEPS } from '../data/dentalData';
import { Clock, Calendar, FileText, CheckCircle2, ShieldAlert, Phone, HelpCircle, MapPin, Heart } from 'lucide-react';

interface PatientInfoProps {
  onOpenAppointmentModal: () => void;
}

export const PatientInfo: React.FC<PatientInfoProps> = ({ onOpenAppointmentModal }) => {
  const requirements = [
    'Identificación oficial con fotografía (INE, pasaporte o credencial escolar vigente).',
    'Clave Única de Registro de Población (CURP).',
    'En caso de menores de edad: asistir acompañados por madre, padre o tutor legal.',
    'Lista clara de medicamentos que tomes de manera habitual o antecedentes alérgicos.',
    'Cubrebocas para el ingreso a áreas clínicas sanitarias.'
  ];

  return (
    <section id="pacientes" className="py-14 sm:py-20 bg-gradient-to-b from-[#FFF8FA] via-white to-[#FFF8FA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E9E1F5] text-[#5C4D7D] text-xs font-bold uppercase tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-[#8869B3]" />
            <span>Guía de Atención y Primera Vez</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Información esencial para <span className="text-[#D979A0]">pacientes</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Todo lo que necesitas saber antes de tu visita a la Clínica Calafia de la Facultad de Odontología UABC en Mexicali.
          </p>
        </div>

        {/* 4 Steps for First-Time Patients */}
        <div className="mb-14 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg sm:text-xl font-bold text-[#38333B] font-display flex items-center gap-2">
              <span className="text-2xl">📋</span>
              <span>Proceso de atención para pacientes de primera vez</span>
            </h3>
            <span className="text-xs text-[#D979A0] font-semibold hidden sm:inline">
              Paso a paso ordenado
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {PATIENT_STEPS.map((s, idx) => (
              <div
                key={idx}
                className="p-5 rounded-3xl bg-white border border-[#F8DDE8] shadow-girly-sm hover:shadow-girly transition-all flex flex-col justify-between space-y-3 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-16 h-16 bg-[#F8DDE8]/40 rounded-bl-full pointer-events-none" />
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold px-2.5 py-0.5 rounded-full bg-[#FFF0F5] text-[#D979A0] border border-[#E9AFC4]">
                      {s.step}
                    </span>
                    <span className="text-[10px] font-bold text-[#777078]">
                      {s.badge}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-[#38333B] font-display pt-1">
                    {s.title}
                  </h4>

                  <p className="text-xs text-[#59525C] leading-relaxed">
                    {s.desc}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#F8DDE8] text-[11px] text-[#D979A0] font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Atención garantizada UABC</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2-Column Split: Requirements vs Clinic Hours & Fees */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Requirements & Documents */}
          <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-3xl border border-[#F8DDE8] shadow-girly space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#FFF0F5] text-[#D979A0] flex items-center justify-center border border-[#E9AFC4]">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-[#38333B] font-display">
                  Requisitos y qué llevar a tu cita
                </h3>
                <p className="text-xs text-[#777078]">
                  Documentación requerida para tu expediente clínico
                </p>
              </div>
            </div>

            <div className="space-y-2.5">
              {requirements.map((req, i) => (
                <div
                  key={i}
                  className="flex items-start gap-2.5 p-3 rounded-2xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs text-[#4A454D]"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#D979A0] shrink-0 mt-0.5" />
                  <span>{req}</span>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-[#FFF0F5] border border-[#E9AFC4] text-xs text-[#59525C] flex items-start gap-2.5">
              <Heart className="w-4 h-4 text-[#D979A0] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#38333B]">Trato digno y respetuoso: </strong>
                Nuestras clínicas están orientadas a servir a la sociedad con calidez humana, paciencia y profesionalismo.
              </div>
            </div>
          </div>

          {/* Right: Hours, University Fees, and Photo of Team */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Hours card */}
            <div className="bg-gradient-to-r from-[#F8DDE8] via-[#FFFFFF] to-[#E9E1F5] p-6 sm:p-7 rounded-3xl border border-[#E9AFC4] shadow-girly space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white text-[#D979A0] flex items-center justify-center border border-[#E9AFC4] shadow-sm">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-[#38333B] font-display">
                    Horarios de Atención Clínica
                  </h3>
                  <p className="text-xs text-[#777078]">
                    Facultad de Odontología Mexicali
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-3 rounded-2xl bg-white/90 border border-[#F8DDE8]">
                  <span className="font-bold text-[#38333B]">Lunes a Viernes:</span>
                  <span className="font-semibold text-[#D979A0]">8:00 AM – 4:00 PM (Solo entre semana)</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-2xl bg-white/90 border border-[#F8DDE8]">
                  <span className="font-bold text-[#38333B]">Sábados y Domingos:</span>
                  <span className="text-[#777078] font-semibold">Cerrado (Fines de semana sin servicio)</span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs">
                <span className="text-[#777078]">Confirmación telefónica única:</span>
                <a
                  href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                  className="font-bold text-[#D979A0] hover:underline flex items-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5" />
                  {INSTITUTIONAL_INFO.phone}
                </a>
              </div>
            </div>

            {/* University Fees Notice with Team Photo */}
            <div className="bg-white p-5 rounded-3xl border border-[#F8DDE8] shadow-girly-sm flex items-center gap-4">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden shrink-0 border border-[#E9AFC4]">
                <img
                  src={INSTITUTIONAL_INFO.teamPhoto}
                  alt="Equipo clínico UABC"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-1">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E9E1F5] text-[#5C4D7D]">
                  Compromiso Social UABC
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-[#38333B]">
                  Cuotas de recuperación accesibles
                </h4>
                <p className="text-[11px] text-[#777078] leading-tight">
                  Como servicio de la Universidad Autónoma de Baja California, los tratamientos son accesibles para toda la comunidad de Mexicali.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
