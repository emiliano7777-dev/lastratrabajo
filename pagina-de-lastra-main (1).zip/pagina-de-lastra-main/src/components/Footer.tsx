import React from 'react';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import { Phone, Mail, MapPin, Facebook, ExternalLink, Heart, Sparkles } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-gradient-to-b from-white via-[#FFF8FA] to-[#F8DDE8]/50 border-t border-[#F8DDE8] pt-12 pb-24 lg:pb-12 text-[#4A454D]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 mb-10">
          
          {/* Brand & Mission */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-[#E9AFC4] shadow-girly-sm p-0.5 bg-white shrink-0">
                <img
                  src={INSTITUTIONAL_INFO.principalLogo}
                  alt="Logo Principal FOM UABC"
                  className="w-full h-full object-contain rounded-xl"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <span className="text-xl font-extrabold text-[#D979A0] font-display">
                  ODOCARE <span className="text-[#38333B]">UABC</span>
                </span>
                <p className="text-xs text-[#777078] font-semibold">
                  Facultad de Odontología · Campus Mexicali
                </p>
              </div>
            </div>

            <p className="text-xs text-[#59525C] leading-relaxed max-w-sm">
              Servicios odontológicos universitarios con calidad, calidez y cuotas accesibles. Comprometidos con la salud bucal y la sonrisa de la comunidad bajacaliforniana.
            </p>

            <div className="p-3 rounded-2xl bg-white border border-[#E9AFC4] shadow-sm flex items-center gap-2 text-xs text-[#D979A0] font-bold">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>"Una sonrisa sana comienza aquí"</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-[#38333B] border-b border-[#F8DDE8] pb-1.5">
              Navegación Rápida
            </h4>
            <ul className="space-y-1.5 text-xs text-[#777078]">
              {['inicio', 'servicios', 'buscador', 'consejos', 'pacientes', 'tecnologia', 'ubicacion', 'contacto'].map((id) => (
                <li key={id}>
                  <button
                    onClick={() => onNavigate(id)}
                    className="hover:text-[#D979A0] transition-colors cursor-pointer capitalize flex items-center gap-1.5"
                  >
                    <span>🌸</span>
                    <span>{id === 'consejos' ? 'Cuidado Dental' : id}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Official Contact Info */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-[#38333B] border-b border-[#F8DDE8] pb-1.5">
              Datos Oficiales
            </h4>
            
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#D979A0] shrink-0" />
                <a
                  href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                  className="font-bold text-[#D979A0] hover:underline"
                >
                  {INSTITUTIONAL_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#D979A0] shrink-0" />
                <a
                  href={`mailto:${INSTITUTIONAL_INFO.email}`}
                  className="text-[#59525C] hover:text-[#D979A0] break-all"
                >
                  {INSTITUTIONAL_INFO.email}
                </a>
              </div>

              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D979A0] shrink-0 mt-0.5" />
                <span className="text-[#59525C] text-[11px] leading-relaxed">
                  {INSTITUTIONAL_INFO.address}
                </span>
              </div>

              <div className="pt-2 flex flex-wrap gap-2">
                <a
                  href={INSTITUTIONAL_INFO.howToGetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#E9E1F5] text-[#5C4D7D] text-[11px] font-bold hover:bg-[#D5C6EC] transition-colors"
                >
                  <span>Cómo llegar</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <a
                  href={INSTITUTIONAL_INFO.facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#EFF6FF] text-[#1877F2] text-[11px] font-bold hover:bg-[#DBEAFE] transition-colors"
                >
                  <Facebook className="w-3 h-3" />
                  <span>Facebook Oficial</span>
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Disclaimer */}
        <div className="pt-6 border-t border-[#F8DDE8] flex flex-col sm:flex-row items-center justify-between text-xs text-[#777078] gap-3 text-center sm:text-left">
          <p>
            © {new Date().getFullYear()} ODOCARE UABC · Facultad de Odontología Mexicali. Todos los derechos reservados.
          </p>
          <p className="flex items-center gap-1 text-[11px]">
            <span>Diseño girly y profesional para la comunidad UABC</span>
            <Heart className="w-3 h-3 text-[#D979A0] fill-[#D979A0]" />
          </p>
        </div>

      </div>
    </footer>
  );
};
