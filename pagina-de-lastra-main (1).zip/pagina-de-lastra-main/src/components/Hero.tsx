import React, { useState } from 'react';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import { Search, Sparkles, MapPin, Phone, ArrowRight } from 'lucide-react';

interface HeroProps {
  onSearchSubmit: (query: string) => void;
  onNavigate: (sectionId: string) => void;
  onOpenAppointmentModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearchSubmit, onNavigate, onOpenAppointmentModal }) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearchSubmit(searchInput);
      onNavigate('buscador');
    }
  };

  const quickCategories = [
    { label: 'Limpieza dental', query: 'Limpieza' },
    { label: 'Caries y resinas', query: 'Caries' },
    { label: 'Ortodoncia / Brackets', query: 'Ortodoncia' },
    { label: 'Muela del juicio', query: 'Cirugía' },
    { label: 'Odontopediatría', query: 'Niños' },
    { label: 'Prótesis y coronas', query: 'Corona' },
  ];

  return (
    <section className="relative overflow-hidden pt-6 pb-14 lg:py-16">
      {/* Decorative soft pastel blobs */}
      <div className="absolute top-0 right-10 -z-10 w-80 h-80 bg-[#F8DDE8]/70 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-5 -z-10 w-96 h-96 bg-[#E9E1F5]/60 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Branding, Tagline, Search, CTAs */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Cute Girly Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FFFFFF] border border-[#E9AFC4]/50 shadow-girly-sm text-xs text-[#777078] font-medium">
              <span className="flex h-2 w-2 rounded-full bg-[#D979A0]" />
              <span className="text-[#D979A0] font-bold">FOM UABC Mexicali</span>
              <span>·</span>
              <span className="flex items-center gap-1 text-[#4A454D]">
                <Sparkles className="w-3 h-3 text-[#D979A0]" />
                Muchos servicios especializados
              </span>
            </div>

            {/* Main Headline */}
            <div className="space-y-2">
              <div className="flex items-center justify-center lg:justify-start gap-3">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden border-2 border-[#E9AFC4] shadow-girly p-1 bg-white shrink-0">
                  <img
                    src={INSTITUTIONAL_INFO.principalLogo}
                    alt="Logo FOM UABC con fondo rosa"
                    className="w-full h-full object-contain rounded-xl"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#38333B] tracking-tight font-display">
                    ODOCARE <span className="text-[#D979A0]">UABC</span>
                  </h1>
                  <p className="text-xs sm:text-sm font-semibold text-[#777078]">
                    Facultad de Odontología · Campus Mexicali
                  </p>
                </div>
              </div>

              <p className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#D979A0] font-display pt-2">
                "{INSTITUTIONAL_INFO.tagline}"
              </p>
            </div>

            {/* Description Paragraph */}
            <p className="text-sm sm:text-base text-[#59525C] leading-relaxed max-w-xl mx-auto lg:mx-0">
              Bienvenida a la plataforma de atención odontológica universitaria. Descubre nuestros muchos servicios especializados con tecnología moderna, cuotas de recuperación accesibles y el cuidado profesional de nuestros docentes y estudiantes.
            </p>

            {/* Treatment Search Box */}
            <div className="bg-[#FFFFFF] p-2.5 sm:p-3 rounded-2xl sm:rounded-3xl border border-[#F8DDE8] shadow-girly max-w-xl mx-auto lg:mx-0">
              <form onSubmit={handleSearch} className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 text-[#E9AFC4] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    placeholder="Busca por síntoma o tratamiento (ej. caries, brackets, limpieza...)"
                    className="w-full pl-10 pr-3 py-2.5 text-xs sm:text-sm rounded-xl focus:outline-none focus:ring-2 focus:ring-[#D979A0]/40 text-[#4A454D] placeholder:text-[#9A939E] bg-[#FFF8FA]"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 sm:px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs sm:text-sm font-bold shadow-girly hover:opacity-95 transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5"
                >
                  <span>Buscar</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>

              {/* Quick tags */}
              <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-[#F8DDE8] overflow-x-auto text-xs pb-1">
                <span className="text-[11px] font-semibold text-[#777078] shrink-0">Popular:</span>
                {quickCategories.map((cat, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      onSearchSubmit(cat.query);
                      onNavigate('buscador');
                    }}
                    className="px-2.5 py-1 rounded-full bg-[#FFF0F5] hover:bg-[#F8DDE8] text-[#D979A0] text-[11px] font-medium transition-colors shrink-0 cursor-pointer border border-[#F8DDE8]"
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick CTAs and Phone Ribbon */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-1">
              <button
                onClick={() => onNavigate('servicios')}
                className="px-5 py-3 rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs sm:text-sm font-bold shadow-girly hover:scale-102 transition-all cursor-pointer flex items-center gap-2"
              >
                <span>Explorar Servicios Especializados</span>
                <Sparkles className="w-4 h-4" />
              </button>

              <a
                href={INSTITUTIONAL_INFO.howToGetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 sm:px-5 py-3 rounded-full bg-[#E9E1F5] hover:bg-[#DFD4EF] text-[#5C4D7D] text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 shadow-sm"
              >
                <MapPin className="w-4 h-4 text-[#8869B3]" />
                <span>Cómo llegar</span>
              </a>

              <a
                href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                className="px-4 sm:px-5 py-3 rounded-full bg-[#FFFFFF] hover:bg-[#FFF0F5] border border-[#E9AFC4] text-[#D979A0] text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 shadow-sm"
              >
                <Phone className="w-4 h-4 text-[#D979A0]" />
                <span>{INSTITUTIONAL_INFO.phone}</span>
              </a>
            </div>

            {/* Value Props Strip */}
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#F8DDE8]/80 text-center">
              <div className="p-2.5 rounded-2xl bg-[#FFFFFF]/70 border border-[#F8DDE8]">
                <p className="text-base sm:text-lg font-extrabold text-[#D979A0] font-display">Muchos</p>
                <p className="text-[11px] text-[#777078] font-medium leading-tight">Servicios Especializados</p>
              </div>
              <div className="p-2.5 rounded-2xl bg-[#FFFFFF]/70 border border-[#F8DDE8]">
                <p className="text-base sm:text-lg font-extrabold text-[#D979A0] font-display">100%</p>
                <p className="text-[11px] text-[#777078] font-medium leading-tight">Supervisión Docente</p>
              </div>
              <div className="p-2.5 rounded-2xl bg-[#FFFFFF]/70 border border-[#F8DDE8]">
                <p className="text-base sm:text-lg font-extrabold text-[#D979A0] font-display">Accesible</p>
                <p className="text-[11px] text-[#777078] font-medium leading-tight">Cuotas Universitarias</p>
              </div>
            </div>

          </div>

          {/* Right Column: Decorative Campus & Community Showcase Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer decorative card frame with girly gradient */}
              <div className="relative rounded-3xl p-3 bg-gradient-to-b from-[#FFFFFF] via-[#FFF8FA] to-[#F8DDE8] border-2 border-[#E9AFC4]/60 shadow-girly overflow-hidden">
                
                {/* Main Hero Photo: Brigada de Salud Oral (Decorative institutional image) */}
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-[#F8DDE8]">
                  <img
                    src={INSTITUTIONAL_INFO.heroPhoto}
                    alt="Facultad de Odontología Mexicali UABC"
                    className="w-full h-full object-cover object-top hover:scale-102 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle contrast gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#251D24]/70 via-transparent to-transparent" />
                  
                  {/* Floating Top Badge */}
                  <div className="absolute top-3 left-3 bg-[#FFFFFF]/95 backdrop-blur-md px-3 py-1.5 rounded-full border border-[#E9AFC4] shadow-sm flex items-center gap-1.5 text-xs font-bold text-[#D979A0]">
                    <Sparkles className="w-3.5 h-3.5 text-[#D979A0]" />
                    <span>Facultad de Odontología Mexicali</span>
                  </div>

                  {/* Floating Bottom Card Over Image */}
                  <div className="absolute bottom-3 inset-x-3 bg-[#FFFFFF]/95 backdrop-blur-md p-3.5 rounded-2xl border border-[#F8DDE8] shadow-girly">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-extrabold text-[#D979A0] uppercase tracking-wide">
                        Clínica Odontológica Calafia
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#E9E1F5] text-[#5C4D7D]">
                        UABC
                      </span>
                    </div>
                    <p className="text-xs text-[#4A454D] font-medium line-clamp-2">
                      Docentes especialistas y cirujanos dentistas al servicio de la salud bucal en Mexicali.
                    </p>
                    <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-[#F8DDE8] text-[11px]">
                      <span className="font-semibold text-[#777078]">Citas & Orientación:</span>
                      <a
                        href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                        className="font-bold text-[#D979A0] hover:underline flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3" />
                        {INSTITUTIONAL_INFO.phone}
                      </a>
                    </div>
                  </div>
                </div>

                {/* Decorative thumbnails with campus photos */}
                <div className="grid grid-cols-2 gap-2 mt-2.5">
                  <div className="flex items-center gap-2 p-2 rounded-2xl bg-[#FFFFFF] border border-[#F8DDE8]">
                    <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-[#E9AFC4]">
                      <img
                        src={INSTITUTIONAL_INFO.clinicFacadePhoto}
                        alt="Clínica Calafia UABC"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[11px] font-bold text-[#38333B] truncate">Clínica Calafia</p>
                      <p className="text-[10px] text-[#777078] truncate">Instalaciones</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-2 rounded-2xl bg-[#FFFFFF] border border-[#F8DDE8]">
                    <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-[#E9AFC4]">
                      <img
                        src={INSTITUTIONAL_INFO.teamPhoto}
                        alt="Equipo de Profesores UABC"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[11px] font-bold text-[#38333B] truncate">Comunidad UABC</p>
                      <p className="text-[10px] text-[#777078] truncate">Docentes y Cirujanos</p>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
