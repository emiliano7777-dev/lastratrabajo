import React, { useState } from 'react';
import { INSTITUTIONAL_INFO, DENTAL_SERVICES } from '../data/dentalData';
import { Mail, Phone, MapPin, Facebook, Send, Copy, Check, Sparkles, Navigation, Heart } from 'lucide-react';

interface ContactSectionProps {
  preselectedService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ preselectedService = '' }) => {
  const [patientName, setPatientName] = useState('');
  const [selectedService, setSelectedService] = useState(preselectedService || 'Odontología preventiva');
  const [patientComments, setPatientComments] = useState('');
  const [copied, setCopied] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const messageText = `Hola, mi nombre es ${patientName || '[Tu Nombre]'}. Deseo solicitar informes y cita para el servicio de: ${selectedService}. Comentarios o síntomas: ${patientComments || 'Valoración general de primera vez'}.`;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Solicitud de Cita / Informes - ${selectedService} - ${patientName || 'Paciente'}`);
    const body = encodeURIComponent(
      `Estimada Facultad de Odontología Mexicali (UABC):\n\n` +
      `Mi nombre es: ${patientName || 'Paciente'}\n` +
      `Servicio odontológico de interés: ${selectedService}\n` +
      `Detalles o motivos de consulta: ${patientComments || 'Deseo agendar una cita de valoración en las clínicas universitarias.'}\n\n` +
      `Quedo atenta/o a su amable respuesta.\n` +
      `Saludos cordiales.`
    );
    window.location.href = `mailto:${INSTITUTIONAL_INFO.email}?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <section id="contacto" className="py-14 sm:py-20 bg-gradient-to-b from-[#FFF8FA] via-white to-[#F8DDE8]/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F8DDE8] text-[#D979A0] text-xs font-bold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5" />
            <span>Atención Personalizada</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Contacto <span className="text-[#D979A0]">institucional</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Comunícate directamente con la Facultad de Odontología Mexicali de la UABC. Estamos listos para atenderte.
          </p>
        </div>

        {/* 2-Column Split: Official Contact Cards + Interactive Request Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Official Contact Direct Access */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Phone Card (strictly the only phone: 686 557 3268) */}
            <div className="p-5 rounded-3xl bg-white border border-[#E9AFC4] shadow-girly space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#FFF0F5] text-[#D979A0] flex items-center justify-center border border-[#E9AFC4]">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-[#777078] uppercase tracking-wider">
                    Único Teléfono Oficial
                  </span>
                  <p className="text-xl font-extrabold text-[#D979A0] font-display">
                    {INSTITUTIONAL_INFO.phone}
                  </p>
                </div>
              </div>
              <p className="text-xs text-[#59525C] leading-relaxed">
                Línea directa para recepción de pacientes, confirmación de turnos y orientación en Clínica Calafia.
              </p>
              <a
                href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] hover:opacity-95 text-white text-xs font-bold shadow-girly-sm flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Phone className="w-4 h-4" />
                <span>Llamar Ahora al {INSTITUTIONAL_INFO.phone}</span>
              </a>
            </div>

            {/* Email Contact Button Card */}
            <div className="p-5 rounded-3xl bg-white border border-[#F8DDE8] shadow-girly-sm space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#E9E1F5] text-[#5C4D7D] flex items-center justify-center">
                  <Mail className="w-6 h-6 text-[#8869B3]" />
                </div>
                <div className="overflow-hidden">
                  <span className="text-[11px] font-bold text-[#777078] uppercase tracking-wider">
                    Correo Electrónico
                  </span>
                  <p className="text-xs sm:text-sm font-bold text-[#38333B] truncate">
                    {INSTITUTIONAL_INFO.email}
                  </p>
                </div>
              </div>
              <p className="text-xs text-[#59525C]">
                Envíanos tus consultas institucionales, solicitudes de servicio o dudas sobre tratamientos.
              </p>
              <a
                href={`mailto:${INSTITUTIONAL_INFO.email}`}
                className="w-full py-2.5 rounded-xl bg-[#FFF8FA] hover:bg-[#F8DDE8] border border-[#E9AFC4] text-[#D979A0] text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>Contacto por correo</span>
              </a>
            </div>

            {/* "Cómo llegar" Official Button */}
            <div className="p-5 rounded-3xl bg-white border border-[#F8DDE8] shadow-girly-sm space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#FFF0F5] text-[#D979A0] flex items-center justify-center border border-[#F8DDE8]">
                  <Navigation className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-[#777078] uppercase tracking-wider">
                    Ubicación Oficial
                  </span>
                  <p className="text-xs sm:text-sm font-bold text-[#38333B]">
                    Portal de la Facultad de Odontología
                  </p>
                </div>
              </div>
              <p className="text-xs text-[#59525C]">
                Consulta el mapa interactivo y la información del portal oficial de la UABC Mexicali.
              </p>
              <a
                href={INSTITUTIONAL_INFO.howToGetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-[#E9E1F5] hover:bg-[#DFD4EF] text-[#5C4D7D] text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
              >
                <MapPin className="w-4 h-4 text-[#8869B3]" />
                <span>Cómo llegar (Google Maps)</span>
              </a>
            </div>

            {/* Official Facebook Social Link */}
            <div className="p-5 rounded-3xl bg-white border border-[#F8DDE8] shadow-girly-sm space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#EFF6FF] text-[#1877F2] flex items-center justify-center">
                  <Facebook className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-[#777078] uppercase tracking-wider">
                    Red Social Oficial
                  </span>
                  <p className="text-xs sm:text-sm font-bold text-[#38333B]">
                    Facebook FOM Mexicali
                  </p>
                </div>
              </div>
              <p className="text-xs text-[#59525C]">
                Sigue las convocatorias, jornadas de salud, eventos académicos y avisos escolares en Facebook.
              </p>
              <a
                href={INSTITUTIONAL_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#1877F2] text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Facebook className="w-4 h-4" />
                <span>Visitar Facebook Oficial</span>
              </a>
            </div>

          </div>

          {/* Right Column: Pre-appointment / Informes Assistant Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#E9AFC4] shadow-girly space-y-5">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFF0F5] text-[#D979A0] text-xs font-bold border border-[#F8DDE8]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Asistente de Informes y Citas</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-[#38333B] font-display">
                Genera tu mensaje de solicitud
              </h3>
              <p className="text-xs text-[#777078]">
                Completa tus datos y envíalo automáticamente al correo oficial de la Facultad: <strong className="text-[#D979A0]">{INSTITUTIONAL_INFO.email}</strong>
              </p>
            </div>

            <form onSubmit={handleSendEmail} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#38333B] mb-1">
                  Tu Nombre Completo:
                </label>
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Ej. Sofía Morales Ramos"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs sm:text-sm text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#38333B] mb-1">
                  Servicio odontológico de tu interés:
                </label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs sm:text-sm text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
                >
                  {DENTAL_SERVICES.map((serv) => (
                    <option key={serv.id} value={serv.name}>
                      {serv.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#38333B] mb-1">
                  Cuéntanos qué molestia sientes o qué tratamiento buscas:
                </label>
                <textarea
                  rows={3}
                  value={patientComments}
                  onChange={(e) => setPatientComments(e.target.value)}
                  placeholder="Ej. Siento molestia al tomar agua fría y me gustaría agendar una limpieza y revisión de caries..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-xs sm:text-sm text-[#4A454D] focus:outline-none focus:ring-2 focus:ring-[#D979A0]"
                />
              </div>

              {/* Message Preview Box */}
              <div className="p-4 rounded-2xl bg-[#FFF8FA] border border-[#E9AFC4]/70 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#D979A0]">Vista previa del mensaje:</span>
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="flex items-center gap-1 text-[11px] font-semibold text-[#777078] hover:text-[#D979A0] cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copiado al portapapeles' : 'Copiar texto'}</span>
                  </button>
                </div>
                <p className="text-xs text-[#59525C] font-mono leading-relaxed bg-white p-3 rounded-xl border border-[#F8DDE8]">
                  "{messageText}"
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 px-5 rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs sm:text-sm font-bold shadow-girly hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar por Correo a paulina.montelongo@uabc.edu.mx</span>
                </button>

                <a
                  href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                  className="py-3 px-5 rounded-full bg-white border border-[#E9AFC4] text-[#D979A0] text-xs sm:text-sm font-bold hover:bg-[#FFF0F5] transition-all flex items-center justify-center gap-2 shadow-sm text-center"
                >
                  <Phone className="w-4 h-4" />
                  <span>Llamar {INSTITUTIONAL_INFO.phone}</span>
                </a>
              </div>

              {submitted && (
                <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Se abrió tu cliente de correo con el mensaje listo. ¡Te esperamos pronto en la Clínica Calafia!</span>
                </div>
              )}
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
