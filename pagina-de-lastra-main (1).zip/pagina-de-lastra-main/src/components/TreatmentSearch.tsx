import React, { useState, useMemo } from 'react';
import { TREATMENTS_DIRECTORY, INSTITUTIONAL_INFO } from '../data/dentalData';
import { Search, Sparkles, AlertCircle, ArrowRight, CheckCircle2, Phone, Filter } from 'lucide-react';

interface TreatmentSearchProps {
  initialQuery?: string;
  onOpenAppointmentModal: (treatmentName?: string) => void;
}

export const TreatmentSearch: React.FC<TreatmentSearchProps> = ({
  initialQuery = '',
  onOpenAppointmentModal,
}) => {
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');

  const categories = ['Todos', 'Preventivo', 'Restaurador', 'Especialidades', 'Quirúrgico', 'Infantil'];

  const filteredTreatments = useMemo(() => {
    return TREATMENTS_DIRECTORY.filter((item) => {
      const matchesCategory = selectedCategory === 'Todos' || item.category === selectedCategory;
      const term = searchTerm.toLowerCase().trim();
      if (!term) return matchesCategory;

      const matchesName = item.name.toLowerCase().includes(term);
      const matchesService = item.serviceName.toLowerCase().includes(term);
      const matchesDesc = item.description.toLowerCase().includes(term);
      const matchesSymptoms = item.symptoms.some(s => s.toLowerCase().includes(term));

      return matchesCategory && (matchesName || matchesService || matchesDesc || matchesSymptoms);
    });
  }, [searchTerm, selectedCategory]);

  return (
    <section id="buscador" className="py-14 sm:py-20 bg-[#FFF8FA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E9E1F5] text-[#5C4D7D] text-xs font-bold uppercase tracking-wider">
            <Search className="w-3.5 h-3.5 text-[#8869B3]" />
            <span>Directorio y Buscador Clínico</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Encuentra el tratamiento ideal para tus <span className="text-[#D979A0]">dientes</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            Escribe lo que sientes o el nombre del procedimiento para descubrir en qué clínica universitaria te podemos atender.
          </p>
        </div>

        {/* Search Bar & Category Controls */}
        <div className="max-w-3xl mx-auto space-y-4 mb-10">
          <div className="relative">
            <Search className="w-5 h-5 text-[#E9AFC4] absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por síntoma (ej: dolor de noche, sangrado, encías, muela rota, brackets...)"
              className="w-full pl-12 pr-10 py-3.5 rounded-2xl bg-white border border-[#E9AFC4]/70 shadow-girly focus:outline-none focus:ring-2 focus:ring-[#D979A0] text-sm text-[#4A454D] placeholder:text-[#9A939E]"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-[#777078] hover:text-[#D979A0] bg-[#F8DDE8] w-6 h-6 rounded-full flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center justify-center gap-1.5 flex-wrap">
            <span className="text-xs font-semibold text-[#777078] mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3 text-[#D979A0]" />
              Filtro:
            </span>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#D979A0] text-white shadow-girly-sm'
                    : 'bg-white text-[#777078] border border-[#F8DDE8] hover:border-[#E9AFC4]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-6 text-xs text-[#777078] border-b border-[#F8DDE8] pb-2">
          <span>
            Mostrando <strong>{filteredTreatments.length}</strong> tratamientos disponibles
          </span>
          {searchTerm && (
            <span>
              Resultados para: <em className="text-[#D979A0]">"{searchTerm}"</em>
            </span>
          )}
        </div>

        {/* Treatments Grid */}
        {filteredTreatments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTreatments.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-3xl p-6 border border-[#F8DDE8] shadow-girly-sm hover:shadow-girly transition-all duration-300 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#FFF0F5] text-[#D979A0] border border-[#F8DDE8]">
                      {item.serviceName}
                    </span>
                    <span className="text-[10px] text-[#777078] font-medium">
                      {item.category}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#38333B] font-display">
                    {item.name}
                  </h3>

                  <p className="text-xs text-[#59525C] leading-relaxed">
                    {item.description}
                  </p>

                  {/* Symptoms badges */}
                  <div>
                    <span className="text-[11px] font-semibold text-[#777078] block mb-1">
                      Indicado si presentas:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {item.symptoms.map((sym, i) => (
                        <span
                          key={i}
                          className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-[#F8DDE8]/60 text-[#4A454D]"
                        >
                          {sym}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Prep Tip */}
                  <div className="p-2.5 rounded-xl bg-[#FFF8FA] border border-[#F8DDE8] text-[11px] text-[#777078]">
                    <strong className="text-[#D979A0]">Consejo previo: </strong>
                    {item.prepTip}
                  </div>
                </div>

                {/* Card Action */}
                <div className="pt-3 border-t border-[#F8DDE8] flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#D979A0]">
                    Cuota Universitaria
                  </span>
                  <button
                    onClick={() => onOpenAppointmentModal(item.name)}
                    className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#D979A0] to-[#E9AFC4] text-white text-xs font-bold shadow-sm hover:opacity-95 transition-all cursor-pointer flex items-center gap-1"
                  >
                    <span>Pedir Informes</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-12 px-4 bg-white rounded-3xl border border-[#F8DDE8] shadow-girly max-w-lg mx-auto space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#FFF0F5] text-[#D979A0] flex items-center justify-center">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-[#38333B]">
              No encontramos resultados para tu búsqueda
            </h3>
            <p className="text-xs text-[#777078] leading-relaxed">
              No te preocupes, en la Facultad de Odontología UABC contamos con valoración médica en Admisión y Diagnóstico para cualquier necesidad oral.
            </p>
            <div className="pt-2">
              <a
                href={`tel:${INSTITUTIONAL_INFO.phone.replace(/\s+/g, '')}`}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#D979A0] text-white text-xs font-bold shadow-girly hover:bg-[#C26289]"
              >
                <Phone className="w-4 h-4" />
                <span>Llamar a Clínica: {INSTITUTIONAL_INFO.phone}</span>
              </a>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
