import React from 'react';
import { INSTITUTIONAL_INFO } from '../data/dentalData';
import { Sparkles, ShieldCheck, Microscope, Cpu, CheckCircle2, Award } from 'lucide-react';

export const TechnologySection: React.FC = () => {
  const techPoints = [
    {
      title: 'Radiología Digital de Baja Dosis',
      desc: 'Sensores intraorales digitales de alta resolución que disminuyen hasta un 80% la radiación y entregan imágenes en segundos para diagnóstico instantáneo.',
      icon: Cpu,
    },
    {
      title: 'Esterilización y Bioseguridad Hospitalaria',
      desc: 'Central de equipos y esterilización (CEYE) con autoclaves a vapor de grado quirúrgico, controles biológicos semanales e instrumental embolsado estéril.',
      icon: ShieldCheck,
    },
    {
      title: 'Unidades Dentales Ergonómicas',
      desc: 'Sillones clínicos de diseño ergonómico para máximo confort del paciente, con sistemas de aspiración de alto volumen y luz LED quirúrgica fría.',
      icon: Sparkles,
    },
    {
      title: 'Investigación y Posgrados Clínicos',
      desc: 'Respaldo científico con programas de posgrado y Doctorado en Ciencias Clínicas Odontológicas (DCCO UABC), aplicando las técnicas más avanzadas.',
      icon: Microscope,
    },
  ];

  return (
    <section id="tecnologia" className="py-14 sm:py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F8DDE8] text-[#D979A0] text-xs font-bold uppercase tracking-wider">
            <Microscope className="w-3.5 h-3.5" />
            <span>Innovación, Ciencia y Seguridad</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#38333B] tracking-tight font-display">
            Tecnología y diagnóstico de <span className="text-[#D979A0]">vanguardia</span>
          </h2>

          <p className="text-sm sm:text-base text-[#777078]">
            La Facultad de Odontología Mexicali combina experiencia académica con tecnología diagnóstica de punta para ofrecerte tratamientos seguros, certeros y cómodos.
          </p>
        </div>

        {/* 4 Tech Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {techPoints.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-3xl bg-[#FFF8FA] border border-[#F8DDE8] shadow-girly-sm hover:shadow-girly transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-[#D979A0] border border-[#E9AFC4] shadow-sm">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-[#38333B] font-display">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#59525C] leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#F8DDE8] flex items-center gap-1.5 text-[11px] font-semibold text-[#D979A0]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Estándar UABC Calafia</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Academic & Faculty Leadership Showcase Banner */}
        <div className="bg-gradient-to-r from-[#F8DDE8] via-white to-[#E9E1F5] p-6 sm:p-10 rounded-3xl border border-[#E9AFC4]/60 shadow-girly grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white text-xs font-bold text-[#D979A0] shadow-sm border border-[#E9AFC4]">
              <Award className="w-3.5 h-3.5 text-[#D979A0]" />
              <span>Liderazgo y Acreditación Académica</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#38333B] font-display">
              Formando a los mejores odontólogos del Noroeste de México
            </h3>

            <p className="text-xs sm:text-sm text-[#59525C] leading-relaxed">
              Bajo la dirección de la Mtra. Herla Aida Vieira Nevarez y un claustro docente de primer nivel, la Facultad de Odontología Mexicali (UABC) mantiene programas acreditados por CONAEDO y posgrados de excelencia en investigación clínica.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
              <div className="p-3 rounded-2xl bg-white border border-[#F8DDE8]">
                <strong className="block text-[#D979A0] font-bold text-sm">50 Años</strong>
                <span className="text-[#777078] text-[11px]">De tradición y sonrisas</span>
              </div>
              <div className="p-3 rounded-2xl bg-white border border-[#F8DDE8]">
                <strong className="block text-[#D979A0] font-bold text-sm">Postgrados</strong>
                <span className="text-[#777078] text-[11px]">Investigación & Posgrados</span>
              </div>
            </div>
          </div>

          {/* Right Visuals from user assets */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-3">
            <div className="rounded-2xl overflow-hidden border-2 border-[#E9AFC4] shadow-girly-sm bg-white aspect-square">
              <img
                src={INSTITUTIONAL_INFO.directoraPhoto}
                alt="Directora FOM UABC Mtra. Herla Aida Vieira Nevarez"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="rounded-2xl overflow-hidden border-2 border-[#E9AFC4] shadow-girly-sm bg-white aspect-square">
              <img
                src={INSTITUTIONAL_INFO.posgradoPhoto}
                alt="Doctorado en Ciencias Clínicas Odontológicas UABC"
                className="w-full h-full object-cover object-top"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
