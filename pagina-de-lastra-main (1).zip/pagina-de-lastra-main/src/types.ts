export interface DentalService {
  id: string;
  name: string;
  shortDesc: string;
  fullDesc: string;
  category: 'preventivo' | 'restaurador' | 'especialidad' | 'quirurgico' | 'infantil';
  image: string;
  iconName: string;
  commonTreatments: string[];
  recommendedFor: string;
  sessionDuration: string;
  cuteQuote: string;
}

export interface TreatmentItem {
  id: string;
  name: string;
  serviceId: string;
  serviceName: string;
  symptoms: string[];
  description: string;
  prepTip: string;
  category: string;
}

export interface SmileTip {
  id: string;
  title: string;
  category: string;
  desc: string;
  action: string;
  sparkleEmoji: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: string;
}
