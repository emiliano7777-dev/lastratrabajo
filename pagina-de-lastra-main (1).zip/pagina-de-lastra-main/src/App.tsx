/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DentalService } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { TreatmentSearch } from './components/TreatmentSearch';
import { SmileCareTips } from './components/SmileCareTips';
import { PatientInfo } from './components/PatientInfo';
import { TechnologySection } from './components/TechnologySection';
import { LocationSection } from './components/LocationSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { AppointmentModal } from './components/AppointmentModal';
import { MobileTabBar } from './components/MobileTabBar';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('inicio');
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<DentalService | null>(null);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState<boolean>(false);
  const [appointmentDefaultService, setAppointmentDefaultService] = useState<string>('Odontología preventiva');
  const [searchInitialQuery, setSearchInitialQuery] = useState<string>('');

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSearchSubmit = (query: string) => {
    setSearchInitialQuery(query);
    handleNavigate('buscador');
  };

  const handleOpenAppointmentModal = (serviceName?: string) => {
    if (serviceName) {
      setAppointmentDefaultService(serviceName);
    }
    setIsAppointmentModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FFF8FA] text-[#4A454D]">
      {/* Top sticky navigation */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenAppointmentModal={() => handleOpenAppointmentModal()}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Section 1: Inicio / Hero */}
        <div id="inicio">
          <Hero
            onSearchSubmit={handleSearchSubmit}
            onNavigate={handleNavigate}
            onOpenAppointmentModal={() => handleOpenAppointmentModal()}
          />
        </div>

        {/* Section 2: 9 Servicios Odontológicos */}
        <ServicesSection
          onSelectService={(service) => setSelectedServiceForModal(service)}
          onOpenAppointmentModal={(serviceName) => handleOpenAppointmentModal(serviceName)}
        />

        {/* Section 3: Buscador de Tratamientos */}
        <TreatmentSearch
          initialQuery={searchInitialQuery}
          onOpenAppointmentModal={(treatmentName) => handleOpenAppointmentModal(treatmentName)}
        />

        {/* Section 4: Consejos para cuidar tu sonrisa */}
        <SmileCareTips />

        {/* Section 5: Información para pacientes */}
        <PatientInfo
          onOpenAppointmentModal={() => handleOpenAppointmentModal()}
        />

        {/* Section 6: Tecnología y Diagnóstico */}
        <TechnologySection />

        {/* Section 7: Ubicación y Cómo llegar */}
        <LocationSection />

        {/* Section 8: Preguntas frecuentes */}
        <FaqSection />

        {/* Section 9: Contacto institucional */}
        <ContactSection
          preselectedService={appointmentDefaultService}
        />
      </main>

      {/* Institutional Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Mobile Fixed Navigation Tab Bar */}
      <MobileTabBar
        activeSection={activeSection}
        onNavigate={handleNavigate}
      />

      {/* Detailed Service Modal */}
      <ServiceDetailModal
        service={selectedServiceForModal}
        onClose={() => setSelectedServiceForModal(null)}
        onOpenAppointmentModal={(serviceName) => handleOpenAppointmentModal(serviceName)}
      />

      {/* Appointment & Inquiry Modal */}
      <AppointmentModal
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        defaultServiceName={appointmentDefaultService}
      />
    </div>
  );
}
